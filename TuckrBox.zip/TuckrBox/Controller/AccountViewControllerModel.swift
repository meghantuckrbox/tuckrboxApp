//
//  AccountViewControllerModel.swift
//  TuckrBox
//
//  Created by Steven Tao on 22/7/2016.
//  Copyright © 2016 ROKO. All rights reserved.
//

import Foundation

struct AccountViewControllerModel {
    
    var orderStatus: Global.OrderStatus
    
    /// Set of default data to be used for the model.
    static var initial: AccountViewControllerModel {
        return AccountViewControllerModel(orderStatus: Global.OrderStatus())
    }
}

func ==(lhs: AccountViewControllerModel, rhs: AccountViewControllerModel) -> Bool {
    return lhs.orderStatus == rhs.orderStatus
}