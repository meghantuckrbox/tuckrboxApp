//
//  MealSelectionViewControllerState.swift
//  TuckrBox
//
//  Created by Steven Tao on 15/7/2016.
//  Copyright © 2016 ROKO. All rights reserved.
//

import Foundation
import UIKit

extension MealSelectionViewController {
    
    enum State: Equatable {
        case firstLaunch
        case viewing(child: Child?, selectedStatus: Global.OrderStatus)
        case loading
        case loadingSuccess
        case loadingFailure(error: ResponseError)
        
        static var selectedStatus: Global.OrderStatus {
            var status = Global.OrderStatus()
            if let children = Global.currentUser?.children where children.count > 0{
                for child in children {
                    status[child] = [Order]()
                }
            } else {
                status[Child.placeHolder] = [Order]()
            }
            return status
            
        }
    }
    
    
}

func ==(lhs: MealSelectionViewController.State, rhs: MealSelectionViewController.State) -> Bool {
    switch (lhs, rhs) {
    case (.firstLaunch, .firstLaunch):
        return true
    case let (.viewing(leftChild, leftStatus), .viewing(rightChild, rightStatus)):
        return leftChild == rightChild && leftStatus == rightStatus
    case (.loading, .loading):
        return true
    case (.loadingSuccess, .loadingSuccess):
        return true
    case let (.loadingFailure(leftError), .loadingFailure(rightError)):
        return leftError == rightError
    default:
        return false
    }
}

