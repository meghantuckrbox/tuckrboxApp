//
//  ZipCodeViewControllerState.swift
//  TuckrBox
//
//  Created by Steven Tao on 13/7/2016.
//  Copyright © 2016 ROKO. All rights reserved.
//

import Foundation

extension ZipCodeViewController {
    enum State {
        case firstLaunch
        case submitting
        case success()
        case failure(error: ResponseError?)
    }
    
}
