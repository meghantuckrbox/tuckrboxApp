//
//  FamilyViewController.swift
//  TuckrBox
//
//  Created by Steven Tao on 14/7/2016.
//  Copyright © 2016 ROKO. All rights reserved.
//

import UIKit

class FamilyViewController: UIViewController, KeyboardEventListener {

    typealias Model = FamilyViewControllerModel
    typealias SaveAction = (child: Child) -> Void
    
    // MARK: Properties
    weak var activeTextView: UITextField?
    @IBOutlet weak var viewTopConstraint: NSLayoutConstraint?
    @IBOutlet weak var addButton: UIButton!
    @IBOutlet weak var activityIndicatorView: UIActivityIndicatorView!
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var rightBarButtonItem: UIBarButtonItem!
    let refreshControl = UIRefreshControl()
    var saveAction: SaveAction?
    
    var model = Model.initial
    var state = State.firstLaunch
    
    
    // MARK: Model & State Types
    
    func withValues(mutations: (inout Model, inout State) -> Void) {
//        let oldModel = model
        mutations(&self.model, &self.state)
        
//        if oldModel != model {
//            modelDidChange()
//        }
        modelDidChange()
        stateDidChange()
        
    }
    
    private func modelDidChange() {
        tableView.reloadData()
    }
    
    private func stateDidChange() {
        switch state {
        case .firstLaunch:
            addBackButton()
            setTranslucentNavigationBar()
            addRefreshControl(refreshControl, tableView: tableView, action: #selector(FamilyViewController.loadData))
            listenKeyboardEventNotification()
            addButton.roundCorner()
            withValues({ (_, state) in state = .viewing })            
            loadData()
            
        case .viewing:
            title = "Manage Family"
            rightBarButtonItem.title = "Edit"
            refreshControl.endRefreshing()
            tableView.reloadData()
            activityIndicatorView.stopAnimating()
            
        case let .preEditing(rows):
            title = "Add or Edit Users"
            rightBarButtonItem.title = "Save"
            tableView.reloadData()
            withValues({ (_, state) in state = .editing(expandedRows: rows) })
            
        case .editing:
            tableView.beginUpdates()
            tableView.endUpdates()
            
        case .saving:
            activityIndicatorView.startAnimating()
            
        case .savingSuccess:
            activityIndicatorView.stopAnimating()
            withValues({ (_, state) in state = .viewing })
            
        case let .savingFailure(error):
            showAlert(error.title, message: error.message)
            withValues({ (_, state) in state = .viewing })
            
        case .loadingList:
            beginRefreshing(tableView, refreshControl: refreshControl)
            
        case .loadingSuccess:
            refreshControl.endRefreshing()
            
        case let .loadingFailure(error):
            showAlert(error.title, message: error.message)
            refreshControl.endRefreshing()
            
        case .buildFamily:
            withValues({ (_, state) in state = .firstLaunch })
            title = "Add or Edit Users"
            rightBarButtonItem.title = "Save"
            tableView.reloadData()
            let newModel = Model(familyItemViewModels: [FamilyItemViewModel(child: Child.initial, index: 0)])
            withValues({ (model, state) in
                model = newModel
                state = .editing(expandedRows: [0])
            })
            
        }
    }

    // MARK: View Life Cycle
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        if state == .buildFamily {
            withValues({ (_, state) in state = .buildFamily })
        } else  {
            withValues({ (_, state) in state = .firstLaunch })
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func viewWillDisappear(animated: Bool) {
        super.viewWillDisappear(animated)
        NSNotificationCenter.defaultCenter().removeObserver(self)
        refreshControl.endRefreshing()
    }
    
    deinit {
        print("deinit")
    }
    
    // MARK: - Helper
    
    func setSaveAction(action: SaveAction) {
        self.saveAction = action
    }
    
    func loadData() {
        guard let user = Global.currentUser else {
            let newState = state
            withValues({ (_, state) in state = newState })
            return
        }
        
        let parameter = Child.GetChildrenRequestParameters(user: user)
        Child.getChildren(parameter) { [weak self](children, error) in
            guard let strongSelf = self else { return }
            if error == nil {
                var familyItemViewModels = [FamilyItemViewModel]()
                for (index, child) in children.enumerate() {
                    familyItemViewModels.append(FamilyItemViewModel(child: child, index: index ))
                }
                
                let newModel = Model(familyItemViewModels: familyItemViewModels)
                let newState = State.loadingSuccess
                strongSelf.withValues({ (model, state) in
                    model = newModel
                    state = newState
                })
            } else {
                strongSelf.withValues({ (_, state) in
                    state = .loadingFailure(error: error!)
                })
            }
            strongSelf.withValues({ (_, state) in state = .viewing })
        }
    }
    
    func save() {
        guard let user = Global.currentUser else { return }
        
        let children: [Child] = model.familyItemViewModels.map { return $0.child }
        let oldState = state
        if model.familyItemViewModels.count == 0 {
            withValues({ (_, state) in state = .savingFailure(error: ("Error", "Must have at least one value")) })
            withValues({ (_, state) in state = oldState })
            return
        }
        
        withValues({ (_, state) in state = .saving })
        
        let parameter = Child.SaveChildrenRequestParameters(user: user, children: children)
        Child.saveChildren(parameter) { [weak self](success, error) in
            guard let strongSelf = self else { return }
            
            if error == nil {
                Global.rootViewController.childMenuView.model = ChildMenuViewModel(children: children)
                if strongSelf.saveAction == nil {
                    strongSelf.withValues({ (_, state) in state = .viewing })
                } else  {
                    strongSelf.saveAction?(child: strongSelf.model.familyItemViewModels[0].child)
                    strongSelf.dismissViewControllerAnimated(true, completion: nil)
                }
            } else {
                strongSelf.withValues({ (_, state) in state = .savingFailure(error: error!) })
                strongSelf.withValues({ (_, state) in state = oldState })
            }
        }
    }
    
    // MARK: - Action
    
    @IBAction func rightBarButtonItemTapped(sender: UIBarButtonItem){
        switch state {
        case .viewing: withValues({ (_, state) in state = .preEditing(expandedRows: [Int]()) })
        default: save()
        }
    }
    
    @IBAction func addButtonTapped(sender: UIButton){
        var newModel = model
        var familyItemViewModel = FamilyItemViewModel(child: Child.initial, index: model.familyItemViewModels.count)            
        newModel.familyItemViewModels.append(familyItemViewModel)
        withValues { (model, state) in
            model = newModel
            if case State.editing(let rows) = state {
                state = .editing(expandedRows: rows)
            }
            state = .preEditing(expandedRows: [Int]())
            
        }
    }
    
}

// MARK: - UITextFieldDelegate

extension FamilyViewController: UITextFieldDelegate {
    func textFieldDidBeginEditing(textField: UITextField) {
        activeTextView = textField
    }
    
    func textFieldDidEndEditing(textField: UITextField) {
        activeTextView = nil
    }
    
    func textFieldShouldReturn(textField: UITextField) -> Bool {
        dismissKeyboard()
        var newModel = model
        newModel.familyItemViewModels[textField.tag].child.name = textField.text!
        withValues { (model, _) in
            model = newModel
        }
        return true
    }
}

// MARK: - UITableViewDataSource

extension FamilyViewController : UITableViewDataSource {
    
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return model.familyItemViewModels.count
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCellWithIdentifier(ClassName(FamilyItemTableViewCell), forIndexPath: indexPath) as! FamilyItemTableViewCell
        cell.familyItemView.nameTextField.textField.tag = indexPath.row
        cell.familyItemView.nameTextField.delegate = self
        cell.familyItemView.setModelDidChangeAction { [weak self](familyItemView, model) in
            guard let strongSelf = self else { return }
            
            var newModel = strongSelf.model
            newModel.familyItemViewModels[model.index] = model
            strongSelf.withValues({ (model, _) in model = newModel })
        }
        cell.familyItemView.withValues { (model, state) in
            model = self.model.familyItemViewModels[indexPath.row]
            state = self.state.familyItemViewState(indexPath.row)
        }
        cell.familyItemView.setHeaderViewDidTappedAction { [weak self](familyItemView) in
            guard let strongSelf = self else { return }
            
            if case State.editing(var rows) = strongSelf.state {
                let cell = tableView.cellForRowAtIndexPath(indexPath) as! FamilyItemTableViewCell
                cell.familyItemView.withValues { _, state in
                    state =  FamilyItemView.State.expand(flag: !cell.familyItemView.state.isExpand)
                }
                if rows.contains(indexPath.row) {
                    rows.removeAtIndex(rows.indexOf(indexPath.row)!)
                } else {
                    rows.append(indexPath.row)
                }
                
                strongSelf.withValues({ (_, state) in state = .editing(expandedRows: rows) })
            } else {
                if Global.isLogin {
//                    Global.currentUser?.selectedChildIndex = familyItemView.model.index
//                    Global.rootViewController.showMealSelection()
                } else {
                    strongSelf.navigationController?.popToRootViewControllerAnimated(false)
                    Global.currentUser?.selectedChildIndex = familyItemView.model.index
                    Global.rootViewController.state = .login
                }
            }
        }
        return cell
    }
    
    func tableView(tableView: UITableView, canEditRowAtIndexPath indexPath: NSIndexPath) -> Bool {
        return state == .viewing
    }
    
    func tableView(tableView: UITableView, commitEditingStyle editingStyle: UITableViewCellEditingStyle, forRowAtIndexPath indexPath: NSIndexPath) {
        if (editingStyle == .Delete) {
            var newModel = model
            newModel.familyItemViewModels.removeAtIndex(indexPath.row)
            withValues({ (model, _) in model = newModel })
        }
    }
    
//    func tableView(tableView: UITableView, editingStyleForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCellEditingStyle {
//        return .None
//    }
//    
//    func tableView(tableView: UITableView, shouldIndentWhileEditingRowAtIndexPath indexPath: NSIndexPath) -> Bool {
//        return false
//    }
    
}

// MARK: - UITableViewDelegate

extension FamilyViewController : UITableViewDelegate {
    
    func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        if case State.editing(let rows) = state {
            if rows.contains(indexPath.row) {
                return FamilyItemView.State.expand(flag: true).viewHeight
            }
            return FamilyItemView.State.expand(flag: false).viewHeight
        } else {
            return FamilyItemView.State.viewing(showArrow: true).viewHeight
        }
    }
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        tableView.deselectRowAtIndexPath(indexPath, animated: false)
        
    }
}