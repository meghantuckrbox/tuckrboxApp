//
//  LoginViewController.swift
//  TuckrBox
//
//  Created by Steven Tao on 1/8/2016.
//  Copyright © 2016 ROKO. All rights reserved.
//

import UIKit

class LoginViewController: UIViewController, KeyboardEventListener {

    // MARK: Properties
    weak var activeTextView: UITextField?
    @IBOutlet weak var viewTopConstraint: NSLayoutConstraint?
    @IBOutlet weak var headerImageView: UIImageView!
    @IBOutlet var textFields: [RoundTextFieldView]!
    @IBOutlet weak var signInButton: UIButton!
    @IBOutlet weak var fbButton: UIButton!
    @IBOutlet weak var activityIndicatorView: UIActivityIndicatorView!
    @IBOutlet weak var textFieldWidth: NSLayoutConstraint!
    @IBOutlet weak var headerViewHeightConstraint: NSLayoutConstraint!
    
    private enum Fields: Int {
        case email
        case password
        
        var displayName: String {
            switch self {
            case .email: return "E-mail"
            case .password: return "Password"
            }
        }
        
        var image: UIImage? {
            let name: String
            switch self {
            case .email: name = "MailIcon"
            case .password: name = "PasswordIcon"
            }
            
            return UIImage(named: name)
        }
        
    }
    
    var state = State.firstLaunch
    
    // MARK: Model & State Types
    
    func withValues(mutations: (inout State) -> Void) {
        
        mutations(&self.state)
        
        stateDidChange()
    }
    
    private func stateDidChange() {
        switch state {
        case .firstLaunch:
            view.layoutIfNeeded()
            addTuckrBoxTitleView()
            addBackButton()
            listenKeyboardEventNotification()
            addTapAction()
            if Env.iPhone4 || Env.iPhone5 {
                let offset: CGFloat = Env.iPhone5 ? 60 : 90
                headerViewHeightConstraint.constant = headerViewHeightConstraint.constant - offset
                fbButton.imageEdgeInsets = UIEdgeInsetsMake(3, -150, 0, 0)
            }
            view.layoutIfNeeded()
            configureHeaderView()
            configureTextFields()
            signInButton.roundCorner()
            fbButton.roundCorner()
            textFieldWidth.constant = view.frame.width - 66
            
        case .validating:
            activityIndicatorView.startAnimating()
        case .signInSuccess():
            activityIndicatorView.stopAnimating()
            navigationController?.popToRootViewControllerAnimated(false)
            Global.rootViewController.state = .login
        case let .signInFailure(error):
            activityIndicatorView.stopAnimating()
            showAlert(error.title, message: error.message)
        }
        
    }
    
    // MARK: View Life Cycle
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        stateDidChange()
    }
    
    override func viewWillDisappear(animated: Bool) {
        super.viewWillDisappear(animated)
        NSNotificationCenter.defaultCenter().removeObserver(self)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // MARK: Helper
    
    func configureHeaderView() {
        headerImageView.roundMask([.BottomLeft, .BottomRight], cornerRadii: CGSizeMake(18, 18))
    }
    
    func configureTextFields(){
        for (index, textField) in textFields.enumerate() {
            textField.delegate = self
            if let field = Fields(rawValue: index) {
                textField.placeHolder = field.displayName
                textField.image = field.image
                textField.secureTextEntry = field == .password
                if field == .password {
                    textField.returnKeyType = .Go
                } else {
                    textField.returnKeyType = .Next
                }
                if field == .email {
                    textField.keyboardType = .EmailAddress
                }
            }
        }
    }
    
    // MARK: - Action
    
    @IBAction func signInButtonClicked(sender: UIButton) {
        if let password = textFields[Fields.password.rawValue].text, email = textFields[Fields.email.rawValue].text where !password.isEmpty && !email.isEmpty {
            state = State.validating
            let parameters = User.LoginRequestParameters(email: email, password: password)
            User.login(parameters, completion: { [weak self](user, error) in
                guard let strongSelf = self else { return }
                
                Global.currentUser = user
                if error == nil {
                    strongSelf.withValues({ (state) in
                        state = .signInSuccess
                    })
                    
                } else {
                    strongSelf.withValues({ (state) in
                        state = .signInFailure(error: error!)
                    })
                    
                }
                })
        } else {
            showAlert("Error", message: "missing Value")
        }
        
    }
    
    @IBAction func fbButtonClicked(sender: UIButton) {
        let parameters = User.LoginRequestParameters(email: "1", password: "1")
        User.login(parameters, completion: { [weak self](user, error) in
            guard let strongSelf = self else { return }
            
            Global.currentUser = user
            if error == nil {
                strongSelf.withValues({ (state) in
                    state = .signInSuccess
                })
                
            } else {
                strongSelf.withValues({ (state) in
                    state = .signInFailure(error: error!)
                })
                
            }
            })

    }

}

extension LoginViewController: UITextFieldDelegate {
    func textFieldDidBeginEditing(textField: UITextField) {
        activeTextView = textField
    }
    
    func textFieldDidEndEditing(textField: UITextField) {
        activeTextView = nil
    }
    
    func textFieldShouldReturn(textField: UITextField) -> Bool {
        dismissKeyboard()
        for (index, roundTextFieldView) in textFields.enumerate() {
            if textField == roundTextFieldView.textField && index+1 < textFields.count{
                textFields[index+1].textField.becomeFirstResponder()
                return true
            }
        }
        signInButtonClicked(signInButton)
        return true
    }
}
