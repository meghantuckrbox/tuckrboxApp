//
//  SignUpViewControllerState.swift
//  TuckrBox
//
//  Created by Steven Tao on 12/8/2016.
//  Copyright © 2016 ROKO. All rights reserved.
//

import Foundation

extension SignUpViewController {
    
    enum State: Equatable {
        case firstLaunch        
        case signUpSuccess
        case signUpFailure(error: ResponseError)
        case zipCheckPassed
    }
    
    
}

func ==(lhs: SignUpViewController.State, rhs: SignUpViewController.State) -> Bool {
    switch (lhs, rhs) {
    case (.firstLaunch, .firstLaunch):
        return true
    case (.signUpSuccess, .signUpSuccess):
        return true
    case let (.signUpFailure(leftError), .signUpFailure(rightError)):
        return leftError.title == rightError.title && leftError.message == rightError.message
        
    case (.zipCheckPassed, .zipCheckPassed):
        return true
    default:
        return false
    }
}