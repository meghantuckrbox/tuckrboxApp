//
//  MealSelectionViewControllerModel.swift
//  TuckrBox
//
//  Created by Steven Tao on 15/7/2016.
//  Copyright © 2016 ROKO. All rights reserved.
//

import Foundation
import UIKit

struct MealSelectionViewControllerModel: Equatable {
    
    var meals: [Meal]
    
    /// Set of default data to be used for the model.
    static var initial: MealSelectionViewControllerModel {
        return MealSelectionViewControllerModel(meals: [Meal]())
    }
}

func ==(lhs: MealSelectionViewControllerModel, rhs: MealSelectionViewControllerModel) -> Bool {
    return lhs.meals == rhs.meals
}