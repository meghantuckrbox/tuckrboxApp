//
//  RootViewControllerState.swift
//  TuckrBox
//
//  Created by Steven Tao on 12/7/2016.
//  Copyright © 2016 ROKO. All rights reserved.
//

import Foundation

extension RootViewController {
    enum State: Equatable {
        case signUp
        case loginSuccess
        case showMenu(flag: Bool)
        case showChildMenu(flag: Bool)
        case login
    }
    
}

func ==(lhs: RootViewController.State, rhs: RootViewController.State) -> Bool {
    switch (lhs, rhs) {
    case (.signUp, .signUp):
        return true
    case (.loginSuccess, .loginSuccess):
        return true
    case let (.showMenu(leftFlag), .showMenu(rightFlag)):
        return leftFlag == rightFlag
    case let (.showChildMenu(leftFlag), .showChildMenu(rightFlag)):
        return leftFlag == rightFlag
    case (.login, .login):
        return true
    default:
        return false
    }
}