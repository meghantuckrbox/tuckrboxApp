//
//  CreateAccountViewControllerState.swift
//  TuckrBox
//
//  Created by Steven Tao on 12/7/2016.
//  Copyright © 2016 ROKO. All rights reserved.
//

import Foundation

extension CreateAccountViewController {
    enum State: Equatable{
        case firstLaunch
        case passwordValidated(password: String, reEnterPassword: String)
        case validating
        case signUpSuccess
        case signUpFailure(error: ResponseError)
        case zipCheckPassed
    }
    
}

func ==(lhs: CreateAccountViewController.State, rhs: CreateAccountViewController.State) -> Bool {
    switch (lhs, rhs) {
    case (.firstLaunch, .firstLaunch):
        return true
        
    case let (.passwordValidated(leftPassword, leftReEnterPassword), .passwordValidated(rightPassword, rightReEnterPassword)):
        return leftPassword == leftReEnterPassword && rightPassword == rightReEnterPassword
        
    case (.validating, .validating):
        return true
        
    case (.signUpSuccess, .signUpSuccess):
        return true
        
    case let (.signUpFailure(leftError), .signUpFailure(rightError)):
        return leftError.title == rightError.title && leftError.message == rightError.message
        
    case (.zipCheckPassed, .zipCheckPassed):
        return true
    default:
        return false
    }
}