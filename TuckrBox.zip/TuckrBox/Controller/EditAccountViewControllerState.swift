//
//  EditAccountViewControllerState.swift
//  TuckrBox
//
//  Created by Steven Tao on 21/7/2016.
//  Copyright © 2016 ROKO. All rights reserved.
//

import Foundation

extension EditAccountViewController {
    
    enum State: Equatable {
        case firstLaunch        
        case showingDelivery(showPicker: Bool)
        case showingPayment(showPicker: Bool)
        case showingMealPlan
    }
    
    
}

func ==(lhs: EditAccountViewController.State, rhs: EditAccountViewController.State) -> Bool {
    switch (lhs, rhs) {
    case (.firstLaunch, .firstLaunch):
        return true
        
    case (.showingDelivery, .showingDelivery):
        return true
        
    case (.showingPayment, .showingPayment):
        return true
        
    case (.showingMealPlan, .showingMealPlan):
        return true
        
    default:
        return false
    }
}