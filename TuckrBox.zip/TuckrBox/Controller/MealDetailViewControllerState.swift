//
//  MealDetailViewControllerState.swift
//  TuckrBox
//
//  Created by Steven Tao on 26/7/2016.
//  Copyright © 2016 ROKO. All rights reserved.
//

import Foundation

extension MealDetailViewController {
    
    enum State: Equatable {
        case firstLaunch        
        
    }
    
    
}

func ==(lhs: MealDetailViewController.State, rhs: MealDetailViewController.State) -> Bool {
    switch (lhs, rhs) {
    case (.firstLaunch, .firstLaunch):
        return true
        
    default:
        return false
    }
}