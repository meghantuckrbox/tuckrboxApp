//
//  MealSelectionViewController.swift
//  TuckrBox
//
//  Created by Steven Tao on 12/7/2016.
//  Copyright © 2016 ROKO. All rights reserved.
//

import UIKit

class MealSelectionViewController: UIViewController {

    typealias Model = MealSelectionViewControllerModel
    
    
    // MARK: Properties
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var reviewButton: UIButton!
    @IBOutlet weak var backButton: UIButton!
    let refreshControl = UIRefreshControl()
    weak var shoppingCartView: ShoppingCartIconView!
    
    var model = Model.initial
    var state = State.firstLaunch
    
    private enum SegueIdentifier: String {
        case orderSummarySegue = "OrderSummarySegue"
        case mealDetailSegue = "MealDetailSegue"
    }
    
    // MARK: Model & State Types
    
    func withValues(mutations: (inout Model, inout State) -> Void) {
        let oldModel = model
        mutations(&self.model, &self.state)
        
        if oldModel != model {
            modelDidChange()
        }
        
        stateDidChange()
    }
    
    private func modelDidChange() {
        tableView.reloadData()
    }
    
    private func stateDidChange() {
        switch state {
        case .firstLaunch:
            view.layoutIfNeeded()
            NSNotificationCenter.defaultCenter().removeObserver(self)
            listenNotification()
            setTranslucentNavigationBar()
            configureTableView()
            configureTitleView()
            configureChildMenu()
            configureShoppingCartView()
            reviewButton.roundCorner()
            backButton.roundCorner()
            withValues({ (_, state) in state = .loading })
            
        case let .viewing(_, status):
            if Global.isLogin {
                Global.rootViewController.state = .showChildMenu(flag: false)
            }
            Global.currentOrderStatus = status
            Global.rootViewController.childMenuView.state = .viewing
            refreshControl.endRefreshing()
//            if let rows = status[child ?? Child.placeHolder] {
//                shoppingCartView.setNumber(rows.count, color: rows.count == 0 ? Styles.redColor : Styles.blueColor)
//            }
            let count = Global.currentOrderCount
            shoppingCartView.setNumber(count, color: count == 0 ? Styles.redColor : Styles.blueColor)
            if let newChild = Global.currentUser?.selectedChild {
                (navigationItem.titleView as! MainTitleView).titleLabel.text = newChild.name
            }
            
            tableView.reloadData()
            
        case .loading:
            // load refreash header
            beginRefreshing(tableView, refreshControl: refreshControl)
            loadData()
            
        case .loadingSuccess:
            // dismiss refreash header
            refreshControl.endRefreshing()
            
        case let .loadingFailure(error):
            // dismiss refreash header
            refreshControl.endRefreshing()
            showAlert(error.title, message: error.message)
            
        }
    }

    // MARK: View Life Cycle
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        stateDidChange()
    }

    override func viewWillDisappear(animated: Bool) {
        super.viewWillDisappear(animated)
        refreshControl.endRefreshing()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    deinit{
        NSNotificationCenter.defaultCenter().removeObserver(self)
    }
    
    // MARK: - Navigation
    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        guard let identifier = segue.identifier.flatMap(SegueIdentifier.init) else { return }
        
        switch identifier {
        case .orderSummarySegue:
            let destinationViewController = segue.destinationViewController as! OrderSummaryViewController
            if case State.viewing(_, let status) = state {
                destinationViewController.model = OrderSummaryViewControllerModel(orderStatus: status)                
            }
        case .mealDetailSegue:
            let destinationViewController = segue.destinationViewController as! MealDetailViewController
            
        }
        
    }
    
    // MARK: Helper
    
    func configureShoppingCartView() {
        shoppingCartView = NSBundle.mainBundle().loadNibNamed(ClassName(ShoppingCartIconView), owner: self, options: nil)[0] as! ShoppingCartIconView
        shoppingCartView.tappedAction = {() -> Void in self.goToSummary()}
        navigationItem.rightBarButtonItem = UIBarButtonItem(customView: shoppingCartView)
    }
    
    func configureTitleView() {
        addMainTitleView("Child's Name", action: { (view) in
            Global.rootViewController.state = .showChildMenu(flag: true)
        })
    }
    
    func configureChildMenu(){
        Global.rootViewController.childMenuView.setModelDidChangeAction({[weak self] (view, model) in
            guard let strongSelf = self else { return }
            strongSelf.reloadCurrentChild()
        })
    }
    
    func configureTableView() {
        addRefreshControl(refreshControl, tableView: tableView, action: #selector(MealSelectionViewController.loadData))
    }
    
    func reloadChild(child: Child, status: Global.OrderStatus) {
        if case State.viewing(_, let status) = state {
            tableView.contentOffset = CGPointMake(0, 0)
            withValues({ (_, state) in
                state = .viewing(child: child, selectedStatus: status)
            })
        }
    }
    
    func reloadCurrentChild() {
        if let newChild = Global.currentUser?.selectedChild {
            if case State.viewing(_, let status) = state {
                tableView.contentOffset = CGPointMake(0, 0)
                withValues({ (_, state) in
                    state = .viewing(child: newChild, selectedStatus: status)
                })
            }
        }
    }
    
    func listenNotification() {
        NSNotificationCenter.defaultCenter().addObserverForName(TuckrBoxNofitication.mealUpdate.rawValue, object: nil, queue: NSOperationQueue.mainQueue(), usingBlock: { (notification) in
            self.withValues({ (_, state) in state = .loading })
        })
        
        NSNotificationCenter.defaultCenter().addObserverForName(TuckrBoxNofitication.childUpdate.rawValue, object: nil, queue: NSOperationQueue.mainQueue(), usingBlock: {[weak self] (notification) in
            guard let strongSelf = self else { return }
            guard let status = Global.currentOrderStatus else { return }
            
            if case State.viewing(let child, _) = strongSelf.state {
                strongSelf.withValues({ (_, state) in
                    state = .viewing(child: child, selectedStatus: status)
                })
            }
        })
        
        NSNotificationCenter.defaultCenter().addObserverForName(TuckrBoxNofitication.showMealSelection.rawValue, object: nil, queue: NSOperationQueue.mainQueue(), usingBlock: { [weak self](notification) in
            guard let strongSelf = self else { return }
            
            strongSelf.navigationController?.popToRootViewControllerAnimated(false)
            strongSelf.reloadCurrentChild()
            Global.rootViewController.childMenuView.state = .viewing
            
//            if let newChild = Global.currentUser?.selectedChild {
//                if case State.viewing(_, let status) = strongSelf.state {
//                    strongSelf.withValues({ (_, state) in
//                        state = .viewing(child: newChild, selectedStatus: status)
//                    })
//                }
//            }
            
        })
    }
    
    func loadData() {
        guard let user = Global.currentUser else {
            withValues({ (_, state) in state = State.viewing(child: nil, selectedStatus: State.selectedStatus)})
            return
        }
        
        let child = Global.currentUser?.selectedChild
        let parameters = Meal.GetMealRequestParameters(user: user, child: child)
        Meal.getMeals(parameters) { [weak self] (meals, error) in
            guard let strongSelf = self else { return }
            if error == nil {
                let newModel = Model(meals: meals)
                let newState = State.loadingSuccess
                strongSelf.withValues({ (model, state) in
                    model = newModel
                    state = newState
                })
            } else {
                strongSelf.state = .loadingFailure(error: error!)
            }
            let newState = State.viewing(child: child, selectedStatus: State.selectedStatus)
            strongSelf.withValues({ (_, state) in state = newState })
        }
    }
    
    // MARK: Action
    
    @IBAction func menuButtonClicked(sender: UIBarButtonItem) {
        Global.rootViewController.state = .showMenu(flag: true)
    }
    
    @IBAction func reviewButtonClicked(sender: UIButton) {
        goToSummary()
    }
    
    @IBAction func familyButtonClicked(sender: UIButton) {
        let storyboard = UIStoryboard(name: "SignUp", bundle: nil)
        let familyViewController = storyboard.instantiateViewControllerWithIdentifier(ClassName(FamilyViewController)) as! FamilyViewController
//        familyViewController.state = FamilyViewController.State.buildFamily
        navigationController?.pushViewController(familyViewController, animated: true)
    }
    
    @IBAction func goToSummary() {
        if let children = Global.currentUser?.children where children.count == 0 {
            goToManageFamily({[weak self] (child) in
                guard let strongSelf = self else { return }
                
                if case State.viewing(_, var status) = strongSelf.state {
                    status[child] = status[Child.placeHolder]
                    status[Child.placeHolder] = nil
                    strongSelf.withValues({ (_, state) in
                        state = .viewing(child: child, selectedStatus: status)
                    })
                }
                
                strongSelf.performSegueWithIdentifier(SegueIdentifier.orderSummarySegue.rawValue, sender: nil)
            })
            
        } else {
            performSegueWithIdentifier(SegueIdentifier.orderSummarySegue.rawValue, sender: nil)
        }
        
    }
    
}

// MARK: - UITableViewDataSource

extension MealSelectionViewController : UITableViewDataSource {
    
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return model.meals.count
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCellWithIdentifier(ClassName(MealTableViewCell), forIndexPath: indexPath) as! MealTableViewCell
        if case State.viewing(let child, let status) = state {
            if let numberOfMeal = Global.currentUser?.plan.numberOfMeal, orders = status[child ?? Child.placeHolder] {
                let completed = numberOfMeal == orders.count
                let meal = model.meals[indexPath.row]
                cell.model = MealTableViewCellModel(meal: meal)
                cell.addAction = {[weak self](model: MealTableViewCellModel) in
                    guard let numberOfMeal = Global.currentUser?.plan.numberOfMeal else { return }
                    guard let strongSelf = self else { return }
                    
                    if case State.viewing(let child, var status) = strongSelf.state {
                        if let orders = status[child ?? Child.placeHolder] {
                            var _orders = orders
                            let meal = strongSelf.model.meals[indexPath.row]
                            let order = Order(meal: meal, count: 1)
                            if orders.contains(order) {
                                _orders.removeObject(order)
                            } else {
                                if numberOfMeal == orders.count {
                                    return
                                }
                                _orders.append(order)
                            }
                            status[child ?? Child.placeHolder] = _orders
                            strongSelf.withValues({ (_, state) in
                                state = .viewing(child: child, selectedStatus: status)
                            })
                        }
                        
                    }
                }
                cell.infoAction = {[weak self](model: MealTableViewCellModel) in
                    guard let strongSelf = self else { return }
                    strongSelf.gotoMealDetailPage(model.meal)
                }

                
                if orders.contains(Order(meal: meal, count: 1)) {
                    cell.selectedView.hidden = completed
                    cell.completedView.hidden = !completed
                } else {
                    cell.selectedView.hidden = true
                    cell.completedView.hidden = true
                }
            }
        }
        return cell
    }
    
}

// MARK: - UITableViewDelegate

extension MealSelectionViewController : UITableViewDelegate {
    
    func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        return 470
    }
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        tableView.deselectRowAtIndexPath(indexPath, animated: false)
        
        gotoMealDetailPage(model.meals[indexPath.row])
    }
}
