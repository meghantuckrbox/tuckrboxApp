//
//  FamilyViewControllerModel.swift
//  TuckrBox
//
//  Created by Steven Tao on 14/7/2016.
//  Copyright © 2016 ROKO. All rights reserved.
//

import Foundation
import UIKit

struct FamilyViewControllerModel: Equatable {
    
    typealias Model = FamilyItemViewModel
    
    var familyItemViewModels: [Model]
    
    /// Set of default data to be used for the model.
    static var initial: FamilyViewControllerModel {
        return FamilyViewControllerModel(familyItemViewModels: [Model]())
    }

}

func ==(lhs: FamilyViewControllerModel, rhs: FamilyViewControllerModel) -> Bool {
    return lhs.familyItemViewModels == rhs.familyItemViewModels
}

