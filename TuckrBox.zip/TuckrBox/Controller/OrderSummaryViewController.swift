//
//  OrderSummaryViewController.swift
//  TuckrBox
//
//  Created by Steven Tao on 20/7/2016.
//  Copyright © 2016 ROKO. All rights reserved.
//

import UIKit

class OrderSummaryViewController: UIViewController {

    typealias Model = OrderSummaryViewControllerModel
    
    
    // MARK: Properties
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var confirmButton: UIButton!
    
    var model = Model.initial
    var state = State.firstLaunch
    
    private enum SegueIdentifier: String {
        case orderConfirmationSegue = "OrderConfirmationSegue"
    }
    
    // MARK: Model & State Types
    
    func withValues(mutations: (inout Model, inout State) -> Void) {
        let oldModel = model
        mutations(&self.model, &self.state)
        
        if oldModel != model {
            modelDidChange()
        }
        stateDidChange()
    }
    
    private func modelDidChange() {
        tableView.reloadData()
    }
    
    private func stateDidChange() {
        switch state {
        case .firstLaunch:
            addBackButton()
            confirmButton.roundCorner()
            title = "Summary"
        case .confirm:
            performSegueWithIdentifier(SegueIdentifier.orderConfirmationSegue.rawValue, sender: nil)
        }

    }
    
    // MARK: View Life Cycle
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        modelDidChange()
        stateDidChange()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // MARK: - Navigation
    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        guard let identifier = segue.identifier.flatMap(SegueIdentifier.init) else { return }
        
        switch identifier {
        case .orderConfirmationSegue:
            let destinationViewController = segue.destinationViewController as! OrderConfirmatioinViewController
            destinationViewController.model = OrderConfirmatioinViewControllerModel(orderStatus: model.orderStatus)
        }
        
    }
    
    // MARK: - Action
    
    @IBAction func confirmButtonTapped(sender: UIButton) {
        withValues { (_, state) in
            state = .confirm
        }
        
    }

}

// MARK: - UITableViewDataSource

extension OrderSummaryViewController : UITableViewDataSource {
    
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1
//        return model.orderStatus.count
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        var numberOfOrder = 0
        for key in model.orderStatus.keys {
            numberOfOrder += model.orderStatus[key]!.count
        }        
        
        return model.orderStatus.keys.count + numberOfOrder
        
//        guard let child = Global.currentUser?.children[section] else { return 0 }
//        return model.orderStatus[child]!.count
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        if model.headerIndexes.contains(indexPath.row) {
            let headerView = tableView.dequeueReusableCellWithIdentifier(ClassName(OrderHeaderView)) as! OrderHeaderView
            
            if let index = model.headerIndexes.indexOf(indexPath.row), child = Global.currentUser?.children[index] {
                headerView.child = child                
                headerView.editButtonClickedAction = { [weak self](child) in
                    guard let strongSelf = self else { return }
                    
                    Global.currentUser?.selectedChildIndex = index
                    if let mealSelectionViewController = strongSelf.navigationController?.viewControllers[0] as? MealSelectionViewController {
                        mealSelectionViewController.reloadChild(child, status: strongSelf.model.orderStatus)
                        //                    mealSelectionViewController.withValues({ (_, state) in
                        //                        state = .viewing(child: child, selectedStatus: strongSelf.model.orderStatus)
                        //                    })
                    }
                    strongSelf.navigationController?.popToRootViewControllerAnimated(true)
                }
                
            }
             return headerView
        } else {
        
            let cell = tableView.dequeueReusableCellWithIdentifier(ClassName(OrderTableViewCell), forIndexPath: indexPath) as! OrderTableViewCell
            
            var index = 0
            for (i, _index) in model.headerIndexes.enumerate() {
                if _index > indexPath.row {
                    break
                }
                index = i
            }
            
            if let child = Global.currentUser?.children[index], orders = model.orderStatus[child] {
                
                let orderIndex = indexPath.row - model.headerIndexes[index] - 1
                
                let order = orders[orderIndex]
                cell.model = OrderTableViewCellModel(child: child, order: order)
                cell.modelDidChangeAction = { [weak self](cell, model) in
                    guard let strongSelf = self else { return }
                    var newModel = strongSelf.model
                    if var orders = newModel.orderStatus[model.child] {
                        orders[orders.indexOf(model.order)!] = model.order
                    }
                }
                cell.infoAction = { [weak self](model) in
                    guard let strongSelf = self else { return }
                    
                    strongSelf.gotoMealDetailPage(model.order.meal)
                }
                
                if orderIndex == 0 && orders.count == 1 {
                    cell.layer.cornerRadius = 10
                    cell.layer.masksToBounds = true
                    cell.backgroundColor = UIColor.whiteColor()
                    
                } else if orderIndex == 0 {
                    cell.round([.TopLeft , .TopRight], cornerRadii: CGSizeMake(10, 10))
                    
                } else if orderIndex == (orders.count - 1) {
                    cell.round([.BottomLeft , .BottomRight], cornerRadii: CGSizeMake(10, 10))
                    cell.seperatorView.hidden = true
                }
                
            }
            
            return cell
        }
    }
    
//    func tableView(tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
//        let headerView = tableView.dequeueReusableCellWithIdentifier(ClassName(OrderHeaderView)) as! OrderHeaderView
//        if let child = Global.currentUser?.children[section] {
//            headerView.child = child
//            headerView.editButtonClickedAction = { [weak self](child) in
//                guard let strongSelf = self else { return }
//                
//                Global.currentUser?.selectedChildIndex = section
//                if let mealSelectionViewController = strongSelf.navigationController?.viewControllers[0] as? MealSelectionViewController {
//                    mealSelectionViewController.reloadChild(child, status: strongSelf.model.orderStatus)
////                    mealSelectionViewController.withValues({ (_, state) in
////                        state = .viewing(child: child, selectedStatus: strongSelf.model.orderStatus)
////                    })                    
//                }
//                strongSelf.navigationController?.popToRootViewControllerAnimated(true)
//            }
//            
//        }
//        let view = UIView()
//        view.addSubview(headerView)
//        var rect = headerView.frame
//        rect.size.width = tableView.frame.width
//        headerView.frame = rect
//        return view
//    }
    
    func tableView(tableView: UITableView, canEditRowAtIndexPath indexPath: NSIndexPath) -> Bool {
        return !model.headerIndexes.contains(indexPath.row)
    }
    
    func tableView(tableView: UITableView, commitEditingStyle editingStyle: UITableViewCellEditingStyle, forRowAtIndexPath indexPath: NSIndexPath) {
        if (editingStyle == .Delete) {
            guard let child = Global.currentUser?.children[indexPath.section] else { return }
            
            var newModel = model
            if var orders = newModel.orderStatus[child] {
                orders.removeAtIndex(indexPath.row)
                newModel.orderStatus[child] = orders
                withValues({ (model, _) in model = newModel })
                
            }
        }
    }
    
}

// MARK: - UITableViewDelegate

extension OrderSummaryViewController : UITableViewDelegate {
    
    func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        return model.headerIndexes.contains(indexPath.row) ? 74 : 102
    }
    
//    func tableView(tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
//        return 74
//    }
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        tableView.deselectRowAtIndexPath(indexPath, animated: false)

    }
}
