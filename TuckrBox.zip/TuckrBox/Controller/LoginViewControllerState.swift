//
//  LoginViewControllerState.swift
//  TuckrBox
//
//  Created by Steven Tao on 1/8/2016.
//  Copyright © 2016 ROKO. All rights reserved.
//

import Foundation

extension LoginViewController {
    
    enum State: Equatable {
        case firstLaunch
        case validating
        case signInSuccess
        case signInFailure(error: ResponseError)
        
    }
    
    
}

func ==(lhs: LoginViewController.State, rhs: LoginViewController.State) -> Bool {
    switch (lhs, rhs) {
    case (.firstLaunch, .firstLaunch):
        return true
    case (.validating, .validating):
        return true
        
    case (.signInSuccess, .signInSuccess):
        return true
        
    case let (.signInFailure(leftError), .signInFailure(rightError)):
        return leftError.title == rightError.title && leftError.message == rightError.message

    default:
        return false
    }
}