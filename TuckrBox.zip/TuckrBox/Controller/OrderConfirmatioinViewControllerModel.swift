//
//  OrderConfirmatioinViewControllerModel.swift
//  TuckrBox
//
//  Created by Steven Tao on 21/7/2016.
//  Copyright © 2016 ROKO. All rights reserved.
//

import Foundation

struct OrderConfirmatioinViewControllerModel {
    
    var orderStatus: Global.OrderStatus
    
    /// Set of default data to be used for the model.
    static var initial: OrderConfirmatioinViewControllerModel {
        return OrderConfirmatioinViewControllerModel(orderStatus: Global.OrderStatus())
    }
}

func ==(lhs: OrderConfirmatioinViewControllerModel, rhs: OrderConfirmatioinViewControllerModel) -> Bool {
    return lhs.orderStatus == rhs.orderStatus
}