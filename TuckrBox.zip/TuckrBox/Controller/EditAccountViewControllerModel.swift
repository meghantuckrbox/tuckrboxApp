//
//  EditAccountViewControllerModel.swift
//  TuckrBox
//
//  Created by Steven Tao on 21/7/2016.
//  Copyright © 2016 ROKO. All rights reserved.
//

import Foundation


struct EditAccountViewControllerModel {
    
    var user: User
    
    /// Set of default data to be used for the model.
    static var initial: EditAccountViewControllerModel {
        return EditAccountViewControllerModel(user: User.initial)
    }
}

func ==(lhs: EditAccountViewControllerModel, rhs: EditAccountViewControllerModel) -> Bool {
    return lhs.user == rhs.user
}