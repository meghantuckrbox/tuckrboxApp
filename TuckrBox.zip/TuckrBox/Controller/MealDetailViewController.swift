//
//  MealDetailViewController.swift
//  TuckrBox
//
//  Created by Steven Tao on 26/7/2016.
//  Copyright © 2016 ROKO. All rights reserved.
//

import UIKit

class MealDetailViewController: UIViewController {
    
    typealias Model = MealDetailViewControllerModel
    
    // MARK: Properties
    @IBOutlet weak var mainImageView: UIImageView!
    @IBOutlet weak var mainNameLabel: UILabel!
    @IBOutlet weak var mainDescriptionLabel: UILabel!
    @IBOutlet weak var slide1ImageView: UIImageView!
    @IBOutlet weak var slide1NameLabel: UILabel!
    @IBOutlet weak var slide1DescriptionLabel: UILabel!
    @IBOutlet weak var slide2ImageView: UIImageView!
    @IBOutlet weak var slide2NameLabel: UILabel!
    @IBOutlet weak var slide2DescriptionLabel: UILabel!
    @IBOutlet weak var ingredientsCollectionView: UICollectionView!
    @IBOutlet weak var ingredientsShowAllButton: UIButton!
    @IBOutlet weak var nutritionTextView: UITextView!
    @IBOutlet weak var continueButton: UIButton!


    var model = Model.initial
    var state = State.firstLaunch
    
    // MARK: Model & State Types
    
    func withValues(mutations: (inout Model, inout State) -> Void) {
        
        mutations(&self.model, &self.state)
        
        modelDidChange()
        stateDidChange()
    }
    
    private func modelDidChange() {
        mainImageView.image = UIImage(named: model.meal.image)
        mainNameLabel.text = model.meal.name
        
        ingredientsCollectionView.reloadData()
    }
    
    private func stateDidChange() {
        switch state {
        case .firstLaunch:
            title = "Meal Details"
            addBackButton()
            configureTextView()
            continueButton.roundCorner()
        }
        
    }
    
    // MARK: View Life Cycle
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        modelDidChange()
        stateDidChange()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // MARK: - Helper
    
    func configureTextView() {
        view.layoutIfNeeded()
        let attributedString = nutritionTextView.attributedText.mutableCopy()
        attributedString.addAttribute(NSKernAttributeName, value: CGFloat(0.7), range: NSRange(location: 0, length: attributedString.length))
        nutritionTextView.attributedText = attributedString as! NSAttributedString
        
        let width = nutritionTextView.frame.width
        let exclusionPath = UIBezierPath(rect: CGRectMake(width - 67, 166, 67, 47))
        let exclusionPath1 = UIBezierPath(rect: CGRectMake(width - 150, 216, 150, 182))
        nutritionTextView.textContainer.exclusionPaths = [exclusionPath, exclusionPath1]
    }
    
    // MARK: - Action
    
    @IBAction func continueButtonClicked(sender: UIButton) {
        navigationController?.popViewControllerAnimated(true)
    }
}

// MARK: - UICollectionViewDataSource, UICollectionViewDelegate, UICollectionViewDelegateFlowLayout

extension MealDetailViewController : UICollectionViewDataSource, UICollectionViewDelegate, UICollectionViewDelegateFlowLayout {
    
    func collectionView(collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return model.meal.ingredients.count
    }
    
    func collectionView(collectionView: UICollectionView, cellForItemAtIndexPath indexPath: NSIndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCellWithReuseIdentifier("IngredientCell", forIndexPath: indexPath) as! CollectionViewCell
        cell.imageViews![0].image = UIImage(named: model.meal.ingredients[indexPath.row].image)
        cell.labels![0].text = model.meal.ingredients[indexPath.row].name
        return cell
    }
    
//    func collectionView(collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAtIndexPath indexPath: NSIndexPath) -> CGSize {
//        
//    }
    
    func collectionView(collectionView: UICollectionView, didSelectItemAtIndexPath indexPath: NSIndexPath) {
        
    }
}
