//
//  HistoryViewControllerState.swift
//  TuckrBox
//
//  Created by Steven Tao on 26/7/2016.
//  Copyright © 2016 ROKO. All rights reserved.
//

import Foundation

extension HistoryViewController {
    
    enum State: Equatable {
        case firstLaunch
        case viewing(selectedSections: [Int])
        case loading
        case loadingSuccess
        case loadingFailure(error: ResponseError)
    }
    
    
}

func ==(lhs: HistoryViewController.State, rhs: HistoryViewController.State) -> Bool {
    switch (lhs, rhs) {
    case (.firstLaunch, .firstLaunch):
        return true
    case let (.viewing(leftSelectedSections), .viewing(rightSelectedSections)):
        return leftSelectedSections == rightSelectedSections
    case (.loading, .loading):
        return true
    case (.loadingSuccess, .loadingSuccess):
        return true
    case let (.loadingFailure(leftError), .loadingFailure(rightError)):
        return leftError == rightError
    default:
        return false
    }
}