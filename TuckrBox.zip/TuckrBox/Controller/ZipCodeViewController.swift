//
//  ZipCodeViewController.swift
//  TuckrBox
//
//  Created by Steven Tao on 13/7/2016.
//  Copyright © 2016 ROKO. All rights reserved.
//

import UIKit

class ZipCodeViewController: UIViewController, KeyboardEventListener {
    
    // MARK: Properties
    weak var activeTextView: UITextField?
    @IBOutlet weak var viewTopConstraint: NSLayoutConstraint?
    @IBOutlet var textFields: [RoundTextFieldView]!
    @IBOutlet weak var checkButton: UIButton!
    @IBOutlet weak var alertView: UIView!
    @IBOutlet weak var alertButton: UIButton!
    @IBOutlet weak var activityIndicatorView: UIActivityIndicatorView!
    @IBOutlet weak var headerImageView: UIImageView!
    @IBOutlet weak var textFieldWidth: NSLayoutConstraint!
    @IBOutlet weak var headerViewHeightConstraint: NSLayoutConstraint!
    
    private enum Fields: Int {
        case zipCode
        
        var displayName: String {
            switch self {
            case .zipCode: return "Zip Code"
            }
        }
        
    }
    
    private var state = State.firstLaunch {
        didSet {
            switch state {
            case .firstLaunch:
                addTuckrBoxTitleView()
                addBackButton()
                if Env.iPhone4 || Env.iPhone5 {
                    let offset: CGFloat = Env.iPhone5 ? 100 : 130
                    headerViewHeightConstraint.constant = headerViewHeightConstraint.constant - offset
                }
                configureHeaderView()
                listenKeyboardEventNotification()
                addTapAction()
                textFieldWidth.constant = view.frame.width - 66
                for (index, textField) in textFields.enumerate() {
                    textField.delegate = self
                    if let field = Fields(rawValue: index) {
                        textField.placeHolder = field.displayName
                        textField.returnKeyType = .Go
                        textField.hideImageView = true
                        textField.textAlignment = .Left
                    }
                }
                alertButton.roundCorner()
                checkButton.roundCorner()
                
            case .submitting:
                activityIndicatorView.startAnimating()
            case .success():
                activityIndicatorView.stopAnimating()
                Global.currentUser?.zipCheckPassed = true
                navigationController?.popViewControllerAnimated(true)
            case .failure(_):
                activityIndicatorView.stopAnimating()
                Global.currentUser?.zipCheckPassed = false
                UIView.animateWithDuration(0.3) { () -> Void in
                    self.alertView.alpha = 1
                }
            }
        }
    }
    
    
    // MARK: View Life Cycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        state = State.firstLaunch
    }
    
    override func viewWillDisappear(animated: Bool) {
        super.viewWillDisappear(animated)
        NSNotificationCenter.defaultCenter().removeObserver(self)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a @objc @objc little preparation before navigation
     override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
     // Get the new view controller using segue.destinationViewController.
     // Pass the selected object to the new view controller.
     }
     */
    
    // MARK: - Helper
    
    func configureHeaderView() {
        headerImageView.roundMask([.BottomLeft, .BottomRight], cornerRadii: CGSizeMake(18, 18))
    }
    
    // MARK: - Action
    
    @IBAction func checkButtonTapped(sender: UIButton){
        if let zipCode = textFields[Fields.zipCode.rawValue].text where !zipCode.isEmpty {
            state = State.submitting
            let parameters = User.CheckZipCodeRequestParameters(zipCode: zipCode)
            User.checkZipCode(parameters, completion: { [weak self](valid, error) in
                guard let strongSelf = self else { return }
                if valid {
                    strongSelf.state = State.success()
                } else {
                    strongSelf.state = State.failure(error: error)
                }
                })
        } else {
            showAlert("Error", message: "missing Value")
        }
    }
    
}

extension ZipCodeViewController: UITextFieldDelegate {
    func textFieldDidBeginEditing(textField: UITextField) {
        activeTextView = textField
    }
    
    func textFieldDidEndEditing(textField: UITextField) {
        activeTextView = nil
    }
    
    func textFieldShouldReturn(textField: UITextField) -> Bool {
        dismissKeyboard()
        checkButtonTapped(checkButton)
        return true
    }
}
