//
//  OrderConfirmatioinViewController.swift
//  TuckrBox
//
//  Created by Steven Tao on 21/7/2016.
//  Copyright © 2016 ROKO. All rights reserved.
//

import UIKit

class OrderConfirmatioinViewController: UIViewController {

    typealias Model = OrderConfirmatioinViewControllerModel
    
    // MARK: Properties
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var confirmButton: UIButton!
    @IBOutlet weak var backButton: UIButton!
    @IBOutlet weak var successView: UIView!
    @IBOutlet weak var exploreButton: UIButton!
    
    private enum Rows: Int {
        case delivery
        case address
        case payment
        case creditCard
        case mealPlan
        case mealPlanDetail
        case total
        
        var cellHeight: CGFloat {
            switch self {
            case .delivery: return 64
            case .address: return 94
            case .payment: return 64
            case .creditCard: return 50
            case .mealPlan: return 64
            case .mealPlanDetail: return 120
            case .total: return 80
            }
        }
        
        var cellIdentifier: String {
            switch self {
            case .mealPlanDetail: return ClassName(MealPlanTableViewCell)
            default: return "ConfirmationCell\(self.rawValue)"
            }
        }
        
        static var count: Int{
            return 7
        }
        
    }
    
    var model = Model.initial
    var state = State.firstLaunch
    
    // MARK: Model & State Types
    
    func withValues(mutations: (inout Model, inout State) -> Void) {
        
        mutations(&self.model, &self.state)
        
        modelDidChange()
        stateDidChange()
    }
    
    private func modelDidChange() {
        tableView.reloadData()
    }
    
    private func stateDidChange() {
        switch state {
        case .firstLaunch:
            title = "Confirmation"
            configureTableView()
            confirmButton.roundCorner()
            backButton.roundCorner()
            exploreButton.roundCorner()
        
        case .confirm:
            title = "Successful"
            tableView.hidden = true
            successView.hidden = false
            configureSuccessView()
            break
        }
        
    }
    
    // MARK: View Life Cycle
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
        modelDidChange()
        stateDidChange()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // MARK: - Helper
    
    func configureTableView() {
        let cellIdentifier = ClassName(MealPlanTableViewCell)
        tableView.registerNib(UINib(nibName: cellIdentifier, bundle: nil), forCellReuseIdentifier: cellIdentifier)
    }
    
    func configureSuccessView() {
        let maskPath = UIBezierPath(roundedRect: successView.bounds, byRoundingCorners: [.TopLeft , .TopRight], cornerRadii: CGSizeMake(10, 10))
        let maskLayer = CAShapeLayer()
        maskLayer.frame = successView.bounds
        maskLayer.path  = maskPath.CGPath
        maskLayer.fillColor   = UIColor.whiteColor().CGColor
        successView.layer.insertSublayer(maskLayer, atIndex: 0)
    }
    
    // MARK: - Action
    
    @IBAction func confirmButtonTapped(sender: UIButton) {
        withValues { (_, state) in
            state = .confirm
        }
    }
    
    @IBAction func menuButtonClicked(sender: UIBarButtonItem) {
        Global.rootViewController.state = .showMenu(flag: true)
    }
    
    @IBAction func exploreButtonTapped(sender: UIButton) {
        if let mealSelectionViewController = navigationController?.viewControllers[0] as? MealSelectionViewController {
            mealSelectionViewController.withValues({ (_, state) in
                state = .firstLaunch
            })
            
        }
        navigationController?.popToRootViewControllerAnimated(true)
    }
    
}

// MARK: - UITableViewDataSource

extension OrderConfirmatioinViewController : UITableViewDataSource {
    
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return Rows.count
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let row = Rows(rawValue: indexPath.row)
        if row == .mealPlanDetail {
            let cell = tableView.dequeueReusableCellWithIdentifier(row!.cellIdentifier, forIndexPath: indexPath) as! MealPlanTableViewCell
            cell.model = MealPlanTableViewCellModel(plan: Plan.initial)
            return cell
        } else {
            let cell = tableView.dequeueReusableCellWithIdentifier(row!.cellIdentifier, forIndexPath: indexPath) as! TableViewCell
            if row == .delivery {
                cell.round([.TopLeft , .TopRight], cornerRadii: CGSizeMake(10, 10))
            }
            return cell
        }
    }
    
}

// MARK: - UITableViewDelegate

extension OrderConfirmatioinViewController : UITableViewDelegate {
    
    func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        let row = Rows(rawValue: indexPath.row)
        return row!.cellHeight
    }
    
}
