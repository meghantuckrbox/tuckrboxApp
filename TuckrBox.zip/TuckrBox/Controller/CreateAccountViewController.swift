//
//  CreateAccountViewController.swift
//  TuckrBox
//
//  Created by Steven Tao on 12/7/2016.
//  Copyright © 2016 ROKO. All rights reserved.
//

import UIKit

class CreateAccountViewController: UIViewController, KeyboardEventListener {
    
    // MARK: Properties
    weak var activeTextView: UITextField?
    @IBOutlet weak var viewTopConstraint: NSLayoutConstraint?
    @IBOutlet var textFields: [RoundTextFieldView]!
    @IBOutlet weak var signUpButton: UIButton!
    @IBOutlet weak var bottomLabel: UILabel!
    @IBOutlet weak var activityIndicatorView: UIActivityIndicatorView!
    @IBOutlet weak var alertView: UIView!
    @IBOutlet weak var buildNowButton: UIButton!
    @IBOutlet weak var skipNowButton: UIButton!
    @IBOutlet weak var headerImageView: UIImageView!
    @IBOutlet weak var textFieldWidth: NSLayoutConstraint!
    @IBOutlet weak var headerViewHeightConstraint: NSLayoutConstraint!
    
    private enum SegueIdentifier: String {
        case zipCodeSegue = "ZipCodeSegue"
        case familySegue = "FamilySegue"
    }
    
    private enum Fields: Int {
//        case userName
        case email
        case password
        case reEnterPassword
        
        var displayName: String {
            switch self {
//            case .userName: return "Username"
            case .email: return "E-mail"
            case .password: return "Password"
            case .reEnterPassword: return "Re-enter Password"
            }
        }
        
        var image: UIImage? {
            let name: String
            switch self {
//            case .userName: name = "UsernameIcon"
            case .email: name = "MailIcon"
            case .password: name = "PasswordIcon"
            case .reEnterPassword: name = "PasswordIcon"
            }
            
            return UIImage(named: name)
        }
        
    }
    
    private var state = State.firstLaunch {
        didSet {
            switch state {
            case .firstLaunch:
                addTuckrBoxTitleView()
                addBackButton()
                if Env.iPhone4 || Env.iPhone5 {
                    let offset: CGFloat = Env.iPhone5 ? 100 : 130
                    headerViewHeightConstraint.constant = headerViewHeightConstraint.constant - offset
                }
                configureHeaderView()
                listenKeyboardEventNotification()
                addTapAction()
                configureTextFields()
                textFieldWidth.constant = view.frame.width - 66
                buildNowButton.roundCorner()
                skipNowButton.roundCorner()
                signUpButton.roundCorner()
                signUpButton.hidden = true
                
            case let .passwordValidated(password, reEnterPassword):
                if password == reEnterPassword {
                    signUpButton.hidden = false
                    bottomLabel.text = "Let's build lunch!"
                } else {
                    signUpButton.hidden = true
                    bottomLabel.text = "Validate Password Fails"
                }
            case .validating:
                activityIndicatorView.startAnimating()
            case .signUpSuccess():
                activityIndicatorView.stopAnimating()
                performSegueWithIdentifier(SegueIdentifier.zipCodeSegue.rawValue, sender: nil)
            case let .signUpFailure(error):
                activityIndicatorView.stopAnimating()
                showAlert(error.title, message: error.message)
            case .zipCheckPassed:
                alertView.alpha = 0
                UIView.animateWithDuration(0.3) { () -> Void in
                    self.alertView.alpha = 1
                }
            }
        }
    }


    // MARK: View Life Cycle
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        state = State.firstLaunch
    }
    
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(animated)
        if let user = Global.currentUser where user.zipCheckPassed == true{
            state = .zipCheckPassed
        }
    }
    
    override func viewWillDisappear(animated: Bool) {
        super.viewWillDisappear(animated)
        NSNotificationCenter.defaultCenter().removeObserver(self)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    deinit {
        print("deinit")
    }

    
    // MARK: - Navigation
    
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        guard let identifier = segue.identifier.flatMap(SegueIdentifier.init) else { return }
        
        switch identifier {
        case .familySegue:
            let destinationViewController = segue.destinationViewController as! FamilyViewController
            destinationViewController.state = FamilyViewController.State.buildFamily
//            destinationViewController.withValues({ (_, state) in
//                state = FamilyViewController.State.buildFamily
//            })
        default:
            break
        }
        
    }
    
    // MARKL - Helper
    
    func configureHeaderView() {
        headerImageView.roundMask([.BottomLeft, .BottomRight], cornerRadii: CGSizeMake(18, 18))
    }
    
    func configureTextFields(){
        for (index, textField) in textFields.enumerate() {
            textField.delegate = self
            if let field = Fields(rawValue: index) {
                textField.placeHolder = field.displayName
                textField.image = field.image
                textField.secureTextEntry = (field == .password || field == .reEnterPassword)
                if field == .reEnterPassword {
                    textField.returnKeyType = .Go
                } else {
                    textField.returnKeyType = .Next
                }
                if field == .email {
                    textField.keyboardType = .EmailAddress
                }
            }
        }
    }
 
    // MARK: - Action
 
    @IBAction func signUpButtonTapped(sender: UIButton){
        if let password = textFields[Fields.password.rawValue].text, email = textFields[Fields.email.rawValue].text where !password.isEmpty && !email.isEmpty {
            state = State.validating
            let parameters = User.RegisterRequestParameters(email: email, password: password)
            User.register(parameters, completion: { [weak self](user, error) in
                guard let strongSelf = self else { return }
                
                Global.currentUser = user
                if error == nil {
                    strongSelf.state = State.signUpSuccess
                } else {
                    strongSelf.state = State.signUpFailure(error: error!)
                }
            })
        } else {
            showAlert("Error", message: "missing Value")
        }
    }
    
    @IBAction func skipNowButtonTapped(sender: UIButton) {
        navigationController?.popToRootViewControllerAnimated(false)
        Global.rootViewController.state = .login
    }
}

extension CreateAccountViewController: UITextFieldDelegate {
    func textFieldDidBeginEditing(textField: UITextField) {
        activeTextView = textField
    }
    
    func textFieldDidEndEditing(textField: UITextField) {
        activeTextView = nil
        let passwordTextField = textFields[Fields.password.rawValue].textField
        let reEnterPasswordTextField = textFields[Fields.reEnterPassword.rawValue].textField
        if textField == passwordTextField || textField == reEnterPasswordTextField {
            if let password = passwordTextField.text, reEnterPassword = reEnterPasswordTextField.text {
                if state == .firstLaunch {
                    if !password.isEmpty && !reEnterPassword.isEmpty {
                        state = State.passwordValidated(password: password, reEnterPassword: reEnterPassword)
                    }
                } else {
                    state = State.passwordValidated(password: password, reEnterPassword: reEnterPassword)
                }
            }
            
        }
    }
    
    func textFieldShouldReturn(textField: UITextField) -> Bool {
        dismissKeyboard()
        for (index, roundTextFieldView) in textFields.enumerate() {
            if textField == roundTextFieldView.textField && index+1 < textFields.count{
                textFields[index+1].textField.becomeFirstResponder()
                return true
            }
        }
        signUpButtonTapped(signUpButton)
        return true
    }
}

