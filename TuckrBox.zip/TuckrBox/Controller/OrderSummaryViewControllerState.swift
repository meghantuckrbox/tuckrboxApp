//
//  OrderSummaryViewControllerState.swift
//  TuckrBox
//
//  Created by Steven Tao on 20/7/2016.
//  Copyright © 2016 ROKO. All rights reserved.
//

import Foundation

extension OrderSummaryViewController {
    
    enum State: Equatable {
        case firstLaunch
        case confirm
        
    }
    
    
}

func ==(lhs: OrderSummaryViewController.State, rhs: OrderSummaryViewController.State) -> Bool {
    switch (lhs, rhs) {
    case (.firstLaunch, .firstLaunch):
        return true

    case (.confirm, .confirm):
        return true
        
    default:
        return false
    }
}