//
//  MealDetailViewControllerModel.swift
//  TuckrBox
//
//  Created by Steven Tao on 26/7/2016.
//  Copyright © 2016 ROKO. All rights reserved.
//

import Foundation

struct MealDetailViewControllerModel {
    
    var meal: Meal
    
    /// Set of default data to be used for the model.
    static var initial: MealDetailViewControllerModel {
        return MealDetailViewControllerModel(meal: Meal.initial)
    }
}

func ==(lhs: MealDetailViewControllerModel, rhs: MealDetailViewControllerModel) -> Bool {
    return lhs.meal == rhs.meal
}