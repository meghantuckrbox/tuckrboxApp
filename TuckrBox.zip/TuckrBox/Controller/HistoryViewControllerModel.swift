//
//  HistoryViewControllerModel.swift
//  TuckrBox
//
//  Created by Steven Tao on 26/7/2016.
//  Copyright © 2016 ROKO. All rights reserved.
//

import Foundation

struct HistoryViewControllerModel: Equatable {
    
    var history: History
    
    /// Set of default data to be used for the model.
    static var initial: HistoryViewControllerModel {
        return HistoryViewControllerModel(history: History.initial)
    }
}

func ==(lhs: HistoryViewControllerModel, rhs: HistoryViewControllerModel) -> Bool {
    return lhs.history == rhs.history
}