//
//  RootViewController.swift
//  TuckrBox
//
//  Created by Steven Tao on 12/7/2016.
//  Copyright © 2016 ROKO. All rights reserved.
//

import UIKit
import MessageUI

class RootViewController: UIViewController {

    // MARK: Properties
    @IBOutlet weak var signUpContainerView: UIView!
    @IBOutlet weak var mealSelectionContainerView: UIView!
    @IBOutlet weak var accountEditContainerView: UIView!
    @IBOutlet weak var historyContainerView: UIView!
    @IBOutlet weak var menuView: UIView!
    @IBOutlet weak var menuTableView: UITableView!
    @IBOutlet weak var childView: UIView!
    @IBOutlet weak var childMenuView: ChildMenuView!
    @IBOutlet weak var childMenuViewTop: NSLayoutConstraint!
    @IBOutlet weak var childMenuViewHeight: NSLayoutConstraint!
    
    
    private enum SegueIdentifier: String {
        case mealSelectionSegue = "MealSelectionSegue"
    }
    
    private enum Menus: Int {
        case buildYourTuckrBox
        case tobiTuckr
        case ourFood
        case account
        case share
        case viewOrderHistory
        case refer
        
        var displayName: String {
            switch self {
            case .buildYourTuckrBox: return "Build Your TuckrBox"
            case .tobiTuckr: return "Tobi Tuckr"
            case .ourFood: return "Our Food"
            case .account: return "Account"
            case .share: return "Share"
            case .viewOrderHistory: return "Order History"
            case .refer: return "Refer-a-friend"
            }
        }
        
        var color: UIColor {
            switch self {
            case .buildYourTuckrBox: return Styles.greenColor
            case .tobiTuckr: return Styles.redColor
            case .ourFood: return Styles.yellowColor
            case .account: return Styles.purpleColor
            case .share: return Styles.blueColor
            case .viewOrderHistory: return Styles.greenColor
            case .refer: return Styles.redColor
            }
        }
        
        static var total: Int {
            return 7
        }
        
    }
    
    var state = State.signUp {
        didSet {
            switch state {
            case .signUp:
                hideAllContainerViews()
                signUpContainerView.hidden = false
                
            case .loginSuccess:
                signUpContainerView.hidden = true
                mealSelectionContainerView.hidden = false
                
            case let .showMenu(flag):
                if flag && menuView.alpha == 1 || !flag && menuView.alpha == 0{
                    return
                } else {
                    UIView.animateWithDuration(0.3, animations: {
                        self.menuView.alpha = flag ? 1 : 0
                    })
                }
                
            case let .showChildMenu(flag):
                childMenuView.state = .viewing
                if Global.currentUser == nil || childMenuView.model.children != Global.currentUser!.children {
                    childMenuView.model = ChildMenuViewModel.initial
                }
                if flag {
                    childView.hidden = false
                    if let children = Global.currentUser?.children {
                        let count = min(4, children.count)
                        childMenuViewHeight.constant = CGFloat(count) * 85.0
                    }
                    UIView.animateWithDuration(0.3, animations: { () -> Void in
                        self.childMenuViewTop.constant = -10
                        self.view.layoutIfNeeded()
                    })
                } else {
                    UIView.animateWithDuration(0.3, animations: {
                        self.childMenuViewTop.constant = -self.childMenuView.frame.height
                        self.view.layoutIfNeeded()
                        }, completion: { (finished) in
                            self.childView.hidden = true
                    })
                }
                
            case .login:
                NSNotificationCenter.defaultCenter().postNotificationName(TuckrBoxNofitication.mealUpdate.rawValue, object: nil)
                UIView.transitionWithView(view, duration: 0.7, options: .TransitionFlipFromLeft, animations: {
                    self.mealSelectionContainerView.hidden = false
                    }, completion: {(success) in
                        self.signUpContainerView.hidden = true
                        self.state = .loginSuccess
                })
                
            }
        }
    }
    
    // MARK: View Life Cycle
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        Global.rootViewController = self
        configureAllContainerViews()
//        if Global.isDebug {
//            state = .loginSuccess
//        }
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // MARK: Action
    
    @IBAction func dismissChildMenuView() {
        state = .showChildMenu(flag: false)
    }
    
    @IBAction func dismissMenuView() {
        state = .showMenu(flag: false)
    }
    
    // MARK: - Helper
    
    func hideAllContainerViews() {
        signUpContainerView.hidden = true
        mealSelectionContainerView.hidden = true
        accountEditContainerView.hidden = true
        historyContainerView.hidden = true
    }
    
    func configureAllContainerViews() {
        signUpContainerView.layoutIfNeeded()
        mealSelectionContainerView.layoutIfNeeded()
        accountEditContainerView.layoutIfNeeded()
        historyContainerView.layoutIfNeeded()
    }
    
    func showMealSelection() {
        hideAllContainerViews()
        mealSelectionContainerView.hidden = false
        NSNotificationCenter.defaultCenter().postNotificationName(TuckrBoxNofitication.showMealSelection.rawValue, object: nil)        
    }

}

// MARK: - UITableViewDataSource

extension RootViewController : UITableViewDataSource {
    
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return Menus.total
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCellWithIdentifier("MenuTableViewCell", forIndexPath: indexPath) as! TableViewCell
        if let menu = Menus(rawValue: indexPath.row) {
            cell.labels![0].text = menu.displayName
            cell.backgroundColor = menu.color
        }
        
        return cell
    }
    
}

// MARK: - UITableViewDelegate

extension RootViewController : UITableViewDelegate {
    
    func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        return 60
    }
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        tableView.deselectRowAtIndexPath(indexPath, animated: false)
        state = .showMenu(flag: false)
        if let item = Menus(rawValue: indexPath.row) {
            switch item {
            case .buildYourTuckrBox:
                hideAllContainerViews()
                mealSelectionContainerView.hidden = false
            case .account:
                NSNotificationCenter.defaultCenter().postNotificationName(TuckrBoxNofitication.refreshShoppingBag.rawValue, object: nil)
                hideAllContainerViews()
                accountEditContainerView.hidden = false
            case .viewOrderHistory:
                NSNotificationCenter.defaultCenter().postNotificationName(TuckrBoxNofitication.refreshHistory.rawValue, object: nil)
                hideAllContainerViews()
                historyContainerView.hidden = false
            case .share:
                
                guard let shareViewController = ROKOShareViewController.buildControllerWithContentId("test") else { return }
                shareViewController.shareManager.delegate = self
                UINavigationBar.appearance().titleTextAttributes = [NSForegroundColorAttributeName: UIColor.blackColor(), NSFontAttributeName:Styles.kreonBoldFont(20)]
                presentViewController(shareViewController, animated: true, completion: { () -> Void in
//                    UIApplication.sharedApplication().statusBarStyle = .LightContent
                })
                
            case .refer:
                guard let shareViewController = ROKOShareViewController.buildReferralShareController() else { return }
                
                shareViewController.shareManager.delegate = self
                UINavigationBar.appearance().titleTextAttributes = [NSForegroundColorAttributeName: UIColor.blackColor(), NSFontAttributeName:Styles.kreonBoldFont(20)]
                presentViewController(shareViewController, animated: true, completion: { () -> Void in
                    //                    UIApplication.sharedApplication().statusBarStyle = .LightContent
                })
                
            default:
                break
            }
        }
    }
}

// MARK: - ROKOShareDelegate

extension RootViewController: ROKOShareDelegate {
    
    func shareManager(manager: ROKOShare!, didFinishWithActivityType activityType: ROKOShareChannelType,  result: ROKOSharingResult) {
        if result == .Done {
            UINavigationBar.appearance().titleTextAttributes = [NSForegroundColorAttributeName: Styles.yellowColor, NSFontAttributeName:Styles.kreonBoldFont(20)]
        }
    }
    
}

