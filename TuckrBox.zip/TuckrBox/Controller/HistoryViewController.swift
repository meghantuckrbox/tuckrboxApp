//
//  HistoryViewController.swift
//  TuckrBox
//
//  Created by Steven Tao on 26/7/2016.
//  Copyright © 2016 ROKO. All rights reserved.
//

import UIKit

class HistoryViewController: UIViewController {

    typealias Model = HistoryViewControllerModel
    
    // MARK: Properties
    @IBOutlet weak var tableView: UITableView!
    let refreshControl = UIRefreshControl()
    @IBOutlet weak var loadMoreButton: UIButton!
    

    var model = Model.initial
    var state = State.firstLaunch
    
    // MARK: Model & State Types
    
    func withValues(mutations: (inout Model, inout State) -> Void) {
        let oldModel = model
        mutations(&self.model, &self.state)
        
        if oldModel != model {
            modelDidChange()
        }
        
        stateDidChange()
        
    }
    
    private func modelDidChange() {
        tableView.reloadData()
    }
    
    private func stateDidChange() {
        switch state {
        case .firstLaunch:
            title = "Your Orders"
            setTranslucentNavigationBar()
            loadMoreButton.roundCorner()
            configureTableView()
            listenNotification()
            withValues({ (_, state) in state = .loading })
        case .viewing:
            refreshControl.endRefreshing()
            tableView.reloadData()
            
        case .loading:
            // load refreash header
            beginRefreshing(tableView, refreshControl: refreshControl)
            loadData()
            
        case .loadingSuccess:
            // dismiss refreash header
            refreshControl.endRefreshing()
            
        case let .loadingFailure(error):
            // dismiss refreash header
            refreshControl.endRefreshing()
            showAlert(error.title, message: error.message)
        }
        
    }
    
    // MARK: View Life Cycle
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        modelDidChange()
        stateDidChange()
    }
    
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(animated)
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    deinit {
        NSNotificationCenter.defaultCenter().removeObserver(self)
    }
    
    // MARK: - Helper
    
    func listenNotification() {
        NSNotificationCenter.defaultCenter().addObserverForName(TuckrBoxNofitication.refreshHistory.rawValue, object: nil, queue: NSOperationQueue.mainQueue(), usingBlock: { (notification) in
            self.withValues({ (_, state) in state = .loading })
        })
        
    }
    
    func configureTableView() {
        addRefreshControl(refreshControl, tableView: tableView, action: #selector(MealSelectionViewController.loadData))
    }
    
    func loadData() {
        guard let user = Global.currentUser else {
            withValues({ (_, state) in state = State.viewing(selectedSections: [0])})
            return
        }
        
        let parameters = History.GetHistoryRequestParameters(user: user)
        History.getHistory(parameters) { [weak self] (history, error) in
            guard let strongSelf = self else { return }
            
            if error == nil {
                let newModel = Model(history: history)
                let newState = State.loadingSuccess
                strongSelf.withValues({ (model, state) in
                    model = newModel
                    state = newState
                })
            } else {
                strongSelf.state = .loadingFailure(error: error!)
            }
            strongSelf.withValues({ (_, state) in state = .viewing(selectedSections: [0]) })
        }
    }
    
    // MARK: - Action
    
    @IBAction func menuButtonClicked(sender: UIBarButtonItem) {
        Global.rootViewController.state = .showMenu(flag: true)
    }
    
    @IBAction func loadMoreButtonClicked(sender: UIButton) {
        
    }

}

// MARK: - UITableViewDataSource

extension HistoryViewController : UITableViewDataSource {
    
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return model.history.dates.count
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        let key = model.history.dates[section]
        let orders = model.history.orders[key]
        if case State.viewing(let selectedSections) = state {
            return !selectedSections.contains(section) ? 0 : orders?.count ?? 0
        }
        return 0
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCellWithIdentifier("HistoryOrderTableViewCell", forIndexPath: indexPath) as! OrderTableViewCell
        let key = model.history.dates[indexPath.section]
        if let orders = model.history.orders[key] {
            cell.model = OrderTableViewCellModel(child: Child.initial, order: orders[indexPath.row])
            
            if indexPath.row == 0 && orders.count == 1 {
                cell.layer.cornerRadius = 10
                cell.layer.masksToBounds = true
                cell.backgroundColor = UIColor.whiteColor()
                
            } else if indexPath.row == 0 {
                cell.round([.TopLeft , .TopRight], cornerRadii: CGSizeMake(10, 10))
                
            } else if indexPath.row == (orders.count - 1) {
                cell.round([.BottomLeft , .BottomRight], cornerRadii: CGSizeMake(10, 10))
                cell.seperatorView.hidden = true
            }
        }
        return cell
    }
    
    func tableView(tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let headerView = tableView.dequeueReusableCellWithIdentifier(ClassName(HistoryTableViewHeader)) as! HistoryTableViewHeader
        let key = model.history.dates[section]
        if case State.viewing(let selectedSection) = state {
            headerView.model = HistoryTableViewHeaderModel(key: key, isExpand: selectedSection.contains(section) )
        }
        headerView.tapAction = {[weak self] (model) in
            guard let strongSelf = self else { return }
            
            if case State.viewing(var selectedSection) = strongSelf.state {
                if let index = strongSelf.model.history.dates.indexOf(model.key) {
                    if selectedSection.contains(index) {
                       selectedSection.removeObject(index)
                    } else {
                        selectedSection.append(index)
                    }
                    strongSelf.withValues({ (_, state) in
                        state = .viewing(selectedSections: selectedSection)
                    })
                }
                
            }
            
        }
        
        return headerView
    }
    
}

// MARK: - UITableViewDelegate

extension HistoryViewController : UITableViewDelegate {
    
    func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        return 102
    }
    
    func tableView(tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 74
    }
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        tableView.deselectRowAtIndexPath(indexPath, animated: false)
        
        if let status = Global.currentOrderStatus {
            goToOrderSummary(status)
        }
        
//        let key = model.history.dates[indexPath.section]
//        
//        if let orders = model.history.orders[key] {
//            gotoMealDetailPage(orders[indexPath.row].meal)
//        }
    }
}
