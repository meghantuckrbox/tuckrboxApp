//
//  EditAccountViewController.swift
//  TuckrBox
//
//  Created by Steven Tao on 21/7/2016.
//  Copyright © 2016 ROKO. All rights reserved.
//

import UIKit

class EditAccountViewController: UIViewController, KeyboardEventListener {
    
    typealias Model = EditAccountViewControllerModel
    
    // MARK: Properties
    weak var activeTextView: UITextField?
    @IBOutlet weak var viewTopConstraint: NSLayoutConstraint?
    @IBOutlet weak var segmentView: UIView!
    @IBOutlet weak var segmentStackView: UIStackView!
    @IBOutlet weak var deliveryScrollView: UIScrollView!
    @IBOutlet weak var paymentScrollView: UIScrollView!
    @IBOutlet weak var mealPlanTableView: UITableView!
    @IBOutlet weak var deliveryStackViewHeight: NSLayoutConstraint?
    @IBOutlet weak var statePickerHeight: NSLayoutConstraint?
    @IBOutlet weak var paymentStackViewHeight: NSLayoutConstraint?
    @IBOutlet weak var pickerHeight: NSLayoutConstraint?
    @IBOutlet var segmentButtons: [UIButton]!
    @IBOutlet var textFields: [RoundTextFieldView]!
    @IBOutlet var paymentTextFields: [RoundTextFieldView]!
    @IBOutlet var saveButtons: [UIButton]!
    @IBOutlet weak var pauseButton: UIButton!
    @IBOutlet weak var datePickerView: MonthYearPickerView!
    @IBOutlet weak var statePickerView: UIPickerView!
    
    private let states = ["-", "AL", "AK", "AZ", "AR", "CA", "CO", "CT", "DE", "DC", "FL", "GA", "HI", "ID", "IL", "IN", "IA", "KS", "KY", "LA", "ME", "MD", "MA", "MI", "MN", "MS", "MO", "MT", "NE", "NV", "NH", "NJ", "NM", "NY", "NC", "ND", "OH", "OK", "OR", "PA", "RI", "SC", "SD", "TN", "TX", "UT", "VT", "VA", "WA", "WV", "WI", "WY"]
    
    private enum Type: Int {
        case delivery
        case payment
        case mealPlan
    }
    
    private enum DeliveryFields: Int {
        case firstName
        case lastName
        case phone
        case email
        case address
        case apartmentNumber
        case city
        case state
        case zipCode
        
        var displayName: String {
            switch self {
            case .firstName: return "First name"
            case .lastName: return "Last name"
            case .phone: return "Phone"
            case .email: return "E-mail"
            case .city: return "City"
            case .state: return "State"
            case .address: return "Address"
            case .apartmentNumber: return "Apartment Number"
            case .zipCode: return "Zip Code"
            }
        }
        
        var image: UIImage? {
            let name: String
            switch self {
            case .phone: name = "PhoneIcon"
            case .email: name = "MailIcon"
            default: return nil
            }
            
            return UIImage(named: name)
        }
        
        static func contentHeight(showPicker: Bool) -> CGFloat{
            return showPicker ? 664 : 484
        }
        
    }
    
    private enum PaymentFields: Int {
        case cardholderName
        case cardNumber
        case expireDateMM
        case expireDateYYYY
        case cvv
        
        
        var displayName: String {
            switch self {
            case .cardholderName: return ""
            case .cardNumber: return "xxxx-xxxx-xxxx-xxxx"
            case .expireDateMM: return "MM"
            case .expireDateYYYY: return "YYYY"
            case .cvv: return "CVV"
            }
        }
        
        static func contentHeight(showPicker: Bool) -> CGFloat{
            return showPicker ? 452 : 236
        }
        
        
    }
    
    private enum Rows: Int {
        case subscription
        case mealPlanDetail
        
        var cellHeight: CGFloat {
            switch self {
            case .subscription: return 60
            case .mealPlanDetail: return 106
            }
        }
        
        var cellIdentifier: String {
            switch self {
            case .mealPlanDetail: return ClassName(MealPlanTableViewCell)
            default: return "ConfirmationCell\(self.rawValue)"
            }
        }
        
        static var count: Int{
            return 2
        }
        
    }
    
    var model = Model.initial
    var state = State.firstLaunch
    
    // MARK: Model & State Types
    
    func withValues(mutations: (inout Model, inout State) -> Void) {
        
        mutations(&self.model, &self.state)
        
        stateDidChange()
        modelDidChange()
    }
    
    private func modelDidChange() {
        mealPlanTableView.reloadData()
    }
    
    private func stateDidChange() {
        switch state {
        case .firstLaunch:
            setTranslucentNavigationBar()
            configureTableView()
            addTapAction()
            addBackButton()
            title = "Delivery"
            listenKeyboardEventNotification()
            configureTextFields()
            configureSaveButtons()
            configureDatePicker()
            pauseButton.roundCorner()
            pauseButton.layer.borderWidth = 1
            pauseButton.layer.borderColor = UIColor.lightGrayColor().CGColor
            withValues({ (_, state) in
                state = .showingDelivery(showPicker:false)
            })
            
        case let .showingDelivery(showPicker):
            title = "Delivery"
            hideAllContentView()
            resetSegmentButtons()
            segmentButtons[0].selected = true
            segmentButtons[0].backgroundColor = Styles.purpleColor
            deliveryScrollView.hidden = false
            deliveryStackViewHeight?.constant = DeliveryFields.contentHeight(showPicker)
            statePickerHeight?.constant = showPicker ? 180 : 0
            statePickerView.hidden = !showPicker
            
        case let .showingPayment(showPicker):
            title = "Payment"
            hideAllContentView()
            paymentScrollView.hidden = false
            resetSegmentButtons()
            segmentButtons[1].selected = true
            segmentButtons[1].backgroundColor = Styles.purpleColor
            paymentStackViewHeight?.constant = PaymentFields.contentHeight(showPicker)
            pickerHeight?.constant = showPicker ? 216 : 0
        case .showingMealPlan:
            title = "Meal Plan"
            hideAllContentView()
            mealPlanTableView.hidden = false
            resetSegmentButtons()
            segmentButtons[2].selected = true
            segmentButtons[2].backgroundColor = Styles.purpleColor
            
        }
        
    }
    
    // MARK: View Life Cycle
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        stateDidChange()
        modelDidChange()        
    }
    
    override func viewWillDisappear(animated: Bool) {
        super.viewWillDisappear(animated)
        NSNotificationCenter.defaultCenter().removeObserver(self)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // MARK: - Helper
    
    func configureDatePicker() {
        datePickerView.onDateSelected = { [weak self](month: Int, year: Int) in
            guard let strongSelf = self else { return }
            
            strongSelf.paymentTextFields[PaymentFields.expireDateMM.rawValue].text = String(format: "%02d", month)
            strongSelf.paymentTextFields[PaymentFields.expireDateYYYY.rawValue].text = String(format: "%d", year)
        }
    }
    
    func hideAllContentView() {
        deliveryScrollView.hidden = true
        paymentScrollView.hidden = true
        mealPlanTableView.hidden = true
    }
    
    func resetSegmentButtons() {
        for button in segmentButtons {
            button.selected = false
            button.backgroundColor = UIColor.whiteColor()
        }
    }
    
    func configureSaveButtons() {
        for button in saveButtons {
            button.roundCorner()
        }
    }
    
    func configureTableView() {
        let cellIdentifier = ClassName(MealPlanTableViewCell)
        mealPlanTableView.registerNib(UINib(nibName: cellIdentifier, bundle: nil), forCellReuseIdentifier: cellIdentifier)
    }
    
    func configureTextFields(){
        for (index, textField) in textFields.enumerate() {
            textField.delegate = self
            if let field = DeliveryFields(rawValue: index) {
                textField.placeHolder = field.displayName
                textField.image = field.image
                textField.hideImageView = field.image == nil
                textField.secureTextEntry = false
                textField.textAlignment = .Left
                if field == .zipCode {
                    textField.returnKeyType = .Go
                } else {
                    textField.returnKeyType = .Next
                }
                if field == .email {
                    textField.keyboardType = .EmailAddress
                } else if field == .phone {
                    textField.keyboardType = .NumberPad
                }
                if field == .state {
                    textField.showPicker = true
                    textField.showPickerAction = {[weak self](view: RoundTextFieldView) in
                        guard let strongSelf = self else { return }
                        
                        strongSelf.dismissKeyboard()
                        if case State.showingDelivery(let showPicker) = strongSelf.state {
                            strongSelf.withValues({ (_, state) in state = .showingDelivery(showPicker: !showPicker) })
                        } else {
                            strongSelf.withValues({ (_, state) in state = .showingDelivery(showPicker: false) })
                        }
                    }
                }
            }
        }
        
        for (index, textField) in paymentTextFields.enumerate() {
            textField.delegate = self
            if let field = PaymentFields(rawValue: index) {
                textField.placeHolder = field.displayName
                textField.secureTextEntry = false
                textField.textAlignment = .Left
                textField.hideImageView = true
                if field == .cvv {
                    textField.returnKeyType = .Go
                } else {
                    textField.returnKeyType = .Next
                }
                if field == .cardNumber || field == .cvv {
                    textField.keyboardType = .NumberPad
                }
                if field == .expireDateMM || field == .expireDateYYYY {
                    textField.showDatePicker = true
                    textField.showDatePickerAction = {[weak self](view: RoundTextFieldView) in
                        guard let strongSelf = self else { return }
                        
                        strongSelf.dismissKeyboard()
                        if case State.showingPayment(let showPicker) = strongSelf.state {
                            strongSelf.withValues({ (_, state) in state = .showingPayment(showPicker: !showPicker) })
                            
                        } else {
                            strongSelf.withValues({ (_, state) in state = .showingPayment(showPicker: false) })
                        }
                    }
                }
            }
        }
        
    }


    // MARK: Action
    
    @IBAction func menuButtonClicked(sender: UIBarButtonItem) {
        Global.rootViewController.state = .showMenu(flag: true)
    }
    
    @IBAction func saveButtonClicked() {
        
    }
    
    @IBAction func pauseSubscriptionButtonClicked() {
        
    }
    
    @IBAction func segmentButtonClicked(sender: UIButton) {
        hideAllContentView()
        view.endEditing(true)
        
        if let type = Type(rawValue: segmentButtons.indexOf(sender)!) {
            switch type {
            case .delivery:
                withValues({ (_, state) in state = .showingDelivery(showPicker: false) })
            case .payment:
                withValues({ (_, state) in state = .showingPayment(showPicker: false) })
            case .mealPlan:
                withValues({ (_, state) in state = .showingMealPlan })
                
            }
        }
    }

}

extension EditAccountViewController: UITextFieldDelegate {
    func textFieldDidBeginEditing(textField: UITextField) {
        activeTextView = textField
    }
    
    func textFieldDidEndEditing(textField: UITextField) {
        activeTextView = nil
    }
    
    func textFieldShouldReturn(textField: UITextField) -> Bool {
        dismissKeyboard()
        for (index, roundTextFieldView) in textFields.enumerate() {
            if textField == roundTextFieldView.textField && index+1 < textFields.count{
                textFields[index+1].textField.becomeFirstResponder()
                return true
            }
        }
        saveButtonClicked()
        return true
    }
}

// MARK: - UIPickerViewDelegate

extension EditAccountViewController : UIPickerViewDelegate {
    func pickerView(pickerView: UIPickerView, attributedTitleForRow row: Int, forComponent component: Int) -> NSAttributedString? {
        let title = NSAttributedString(string: states[row], attributes: [NSForegroundColorAttributeName:UIColor.whiteColor()])
        return title
    }
    
    func pickerView(pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        textFields[DeliveryFields.state.rawValue].text = states[row].stringByReplacingOccurrencesOfString("-", withString: "")
    }
}

// MARK: - UIPickerViewDataSource

extension EditAccountViewController : UIPickerViewDataSource {
    func numberOfComponentsInPickerView(pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return states.count
    }
}

// MARK: - UITableViewDataSource

extension EditAccountViewController : UITableViewDataSource {
    
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return Rows.count
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let row = Rows(rawValue: indexPath.row)
        if row == .mealPlanDetail {
            let cell = tableView.dequeueReusableCellWithIdentifier(row!.cellIdentifier, forIndexPath: indexPath) as! MealPlanTableViewCell
            cell.model = MealPlanTableViewCellModel(plan: Plan.initial)
            return cell
        } else {
            let cell = tableView.dequeueReusableCellWithIdentifier(row!.cellIdentifier, forIndexPath: indexPath) as! TableViewCell
            if row == .subscription {
                cell.round([.TopLeft , .TopRight], cornerRadii: CGSizeMake(10, 10))
            }
            return cell
        }
    }
    
}

// MARK: - UITableViewDelegate

extension EditAccountViewController : UITableViewDelegate {
    
    func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        let row = Rows(rawValue: indexPath.row)
        return row!.cellHeight
    }
    
}