//
//  OrderConfirmatioinViewControllerState.swift
//  TuckrBox
//
//  Created by Steven Tao on 21/7/2016.
//  Copyright © 2016 ROKO. All rights reserved.
//

import Foundation

extension OrderConfirmatioinViewController {
    
    enum State: Equatable {
        case firstLaunch
        case confirm
        
    }
    
    
}

func ==(lhs: OrderConfirmatioinViewController.State, rhs: OrderConfirmatioinViewController.State) -> Bool {
    switch (lhs, rhs) {
    case (.firstLaunch, .firstLaunch):
        return true
        
    case (.confirm, .confirm):
        return true
        
    default:
        return false
    }
}