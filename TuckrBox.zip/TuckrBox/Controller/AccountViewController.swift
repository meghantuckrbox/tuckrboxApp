//
//  AccountViewController.swift
//  TuckrBox
//
//  Created by Steven Tao on 22/7/2016.
//  Copyright © 2016 ROKO. All rights reserved.
//

import UIKit

class AccountViewController: UIViewController, KeyboardEventListener{
    
    typealias Model = AccountViewControllerModel
    
    // MARK: Properties
    @IBOutlet weak var tableView: UITableView!
    @IBOutlet weak var tableViewFooter: UIView!
    @IBOutlet weak var alertView: UIView!
    @IBOutlet weak var submitButton: UIButton!
    @IBOutlet weak var passwordField: RoundTextFieldView!
    weak var shoppingCartView: ShoppingCartIconView!

    weak var activeTextView: UITextField?
    @IBOutlet weak var viewTopConstraint: NSLayoutConstraint?

    
    private enum Rows: Int {
        case children
        case account
        
        var displayName: String {
            switch self {
            case .children: return "Multiple Children"
            case .account: return "Edit My Account"
            }
        }
        
        var image: UIImage? {
            let name: String
            switch self {
            case .children: name = "AddChildrenIcon"
            case .account: name = "DeliveryIcon"
            }
            
            return UIImage(named: name)
        }
        
        static var cellHeight: CGFloat {
            return 84.0
        }
        
        static var count: Int {
            return 2
        }
        
    }
    
    private enum SegueIdentifier: String {
        case editAccountSegue = "EditAccountSegue"
        
    }
    
    var model = Model.initial
    var state = State.firstLaunch
    
    // MARK: Model & State Types
    
    func withValues(mutations: (inout Model, inout State) -> Void) {
        
        mutations(&self.model, &self.state)
        
        modelDidChange()
        stateDidChange()
    }
    
    private func modelDidChange() {
        tableView.reloadData()
        let count = Global.currentOrderCount
        shoppingCartView.setNumber(count, color: count == 0 ? Styles.redColor : Styles.blueColor)
    }
    
    private func stateDidChange() {
        switch state {
        case .firstLaunch:
            listenKeyboardEventNotification()
            addTapAction()
            configureTextField()
            setTranslucentNavigationBar()
            addTuckrBoxTitleView()
            listenNotification()
            configureShoppingCartView()
            submitButton.roundCorner()
            withValues({ (_, state) in
                state = .askingPassword
            })
            
        case .askingPassword:
            UIView.animateWithDuration(0.3, animations: { 
                self.alertView.alpha = 1
            })
            
            
        case .validedPassword:
            view.endEditing(true)
            UIView.animateWithDuration(0.3, animations: {
                self.alertView.alpha = 0
            })
            if let gestureRecognizers = view.gestureRecognizers {
                for gestureRecognizer in gestureRecognizers {
                    view.removeGestureRecognizer(gestureRecognizer)
                }
            }
        }
        
    }
    
    // MARK: View Life Cycle
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        stateDidChange()
        modelDidChange()
        
    }
    
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(animated)
        
    }
    
    override func viewWillDisappear(animated: Bool) {
        super.viewWillDisappear(animated)
        NSNotificationCenter.defaultCenter().removeObserver(self)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    deinit {
        NSNotificationCenter.defaultCenter().removeObserver(self)
    }
    
    // MARK: - Helper
    
    func listenNotification() {
        NSNotificationCenter.defaultCenter().addObserverForName(TuckrBoxNofitication.refreshShoppingBag.rawValue, object: nil, queue: NSOperationQueue.mainQueue(), usingBlock: {[weak self] (notification) in
            guard let strongSelf = self else { return }
            
            if let status = Global.currentOrderStatus {
                strongSelf.withValues { (model, _) in model = AccountViewControllerModel(orderStatus: status) }
            }
        })
    }
    
    func configureShoppingCartView() {
        shoppingCartView = NSBundle.mainBundle().loadNibNamed(ClassName(ShoppingCartIconView), owner: self, options: nil)[0] as! ShoppingCartIconView
        shoppingCartView.tappedAction = {() -> Void in self.goToSummary()}
        navigationItem.rightBarButtonItem = UIBarButtonItem(customView: shoppingCartView)
    }
    
    func configureTableView() {
        let maskPath = UIBezierPath(roundedRect: tableView.bounds, byRoundingCorners: [.BottomLeft, .BottomRight], cornerRadii: CGSizeMake(10, 10))
        let maskLayer = CAShapeLayer()
        maskLayer.frame = tableView.bounds
        maskLayer.path  = maskPath.CGPath
        maskLayer.fillColor = Styles.purpleColor.CGColor
        tableView.layer.insertSublayer(maskLayer, atIndex: 0)
        
        
    }
    
    func configureTextField(){
        passwordField.delegate = self
        passwordField.placeHolder = "Password"
        passwordField.image = UIImage(named: "")
        passwordField.secureTextEntry = true
        passwordField.returnKeyType = .Go
    }
    
    // MARK: - Action
    
    @IBAction func menuButtonClicked(sender: UIBarButtonItem) {
        Global.rootViewController.state = .showMenu(flag: true)
    }
    
    @IBAction func submitButtonClicked(sender: UIButton) {
        withValues { (_, state) in
            state = .validedPassword
        }
    }
    
    @IBAction func goToSummary() {
        if let children = Global.currentUser?.children where children.count == 0 {
            goToManageFamily({[weak self] (child) in
                guard let strongSelf = self else { return }
                var status = strongSelf.model.orderStatus
                status[child] = status[Child.placeHolder]
                status[Child.placeHolder] = nil
                strongSelf.model.orderStatus = status
                strongSelf.goToOrderSummary(status)

            })
            
        } else {
            goToOrderSummary(model.orderStatus)
        }
        
    }
    
    @IBAction func logoutButtonClicked() {
        Global.rootViewController.state = .signUp
        Global.currentUser = nil
        Global.currentOrderStatus = nil
    }


}


// MARK: - UITableViewDataSource

extension AccountViewController : UITableViewDataSource {
    
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return Rows.count
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCellWithIdentifier("AccountCell", forIndexPath: indexPath) as! TableViewCell
        if let row = Rows(rawValue: indexPath.row) {
            cell.imageViews![0].image = row.image
            cell.labels![0].text = row.displayName
            if Env.iPhone4 || Env.iPhone5 {
                cell.labels![0].setFontSize(15)
                cell.stackViews![0].spacing = 15
            }
        }
        
        return cell
    }
    
}

// MARK: - UITableViewDelegate

extension AccountViewController : UITableViewDelegate {
    
    func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        return Rows.cellHeight
    }
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        tableView.deselectRowAtIndexPath(indexPath, animated: false)
        if let row = Rows(rawValue: indexPath.row) {
            switch row {
            case .children:
                let storyboard = UIStoryboard(name: "SignUp", bundle: nil)
                let familyViewController = storyboard.instantiateViewControllerWithIdentifier(ClassName(FamilyViewController)) as! FamilyViewController
                navigationController?.pushViewController(familyViewController, animated: true)                
            case .account:
                performSegueWithIdentifier(SegueIdentifier.editAccountSegue.rawValue, sender: nil)
            }
        }
    }
}

extension AccountViewController: UITextFieldDelegate {
    func textFieldDidBeginEditing(textField: UITextField) {
        activeTextView = textField
    }
    
    func textFieldDidEndEditing(textField: UITextField) {
        activeTextView = nil
    }
    
    func textFieldShouldReturn(textField: UITextField) -> Bool {
        dismissKeyboard()
        submitButtonClicked(submitButton)
        return true
    }
}