//
//  AccountViewControllerState.swift
//  TuckrBox
//
//  Created by Steven Tao on 22/7/2016.
//  Copyright © 2016 ROKO. All rights reserved.
//

import Foundation

extension AccountViewController {
    
    enum State: Equatable {
        case firstLaunch
        case askingPassword
        case validedPassword
        
    }
    
    
}

func ==(lhs: AccountViewController.State, rhs: AccountViewController.State) -> Bool {
    switch (lhs, rhs) {
    case (.firstLaunch, .firstLaunch):
        return true
        
    case (.askingPassword, .askingPassword):
        return true
        
    case (.validedPassword, .validedPassword):
        return true
        
    default:
        return false
    }
}