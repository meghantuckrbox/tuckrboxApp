//
//  FamilyViewControllerState.swift
//  TuckrBox
//
//  Created by Steven Tao on 14/7/2016.
//  Copyright © 2016 ROKO. All rights reserved.
//

import Foundation
import UIKit

extension FamilyViewController {
    enum State: Equatable {
        case firstLaunch
        case buildFamily
        case viewing
        case preEditing(expandedRows: [Int])
        case editing(expandedRows: [Int])
        case saving
        case savingSuccess
        case savingFailure(error: ResponseError)
        case loadingList
        case loadingSuccess
        case loadingFailure(error: ResponseError)
        
        
        func familyItemViewState(index: Int) -> FamilyItemView.State {
            if case State.editing(let rows) = self {
                if rows.contains(index) {
                    return .expand(flag: true)
                }
                return .expand(flag: false)
            }
            return .viewing(showArrow: true)            
        }
                
    }
    
}

func ==(lhs: FamilyViewController.State, rhs: FamilyViewController.State) -> Bool {
    switch (lhs, rhs) {
    case (.firstLaunch, .firstLaunch):
        return true
    case (.viewing, .viewing):
        return true
    case (.buildFamily, .buildFamily):
        return true
    case let (.editing(leftExpandedRows), .editing(rightExpandedRows)):
        return leftExpandedRows == rightExpandedRows
    case let (.preEditing(leftExpandedRows), .preEditing(rightExpandedRows)):
        return leftExpandedRows == rightExpandedRows    
    default:
        return false
    }
}