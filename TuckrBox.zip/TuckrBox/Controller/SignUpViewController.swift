//
//  SignUpViewController.swift
//  TuckrBox
//
//  Created by Steven Tao on 12/7/2016.
//  Copyright © 2016 ROKO. All rights reserved.
//

import UIKit
import FBSDKCoreKit
import FBSDKLoginKit
import FBSDKShareKit

class SignUpViewController: UIViewController {

    // MARK: Properties
    @IBOutlet weak var signUpButton: UIButton!
    @IBOutlet weak var facebookButton: UIButton!
    @IBOutlet weak var loginButton: UIButton!
    @IBOutlet weak var headerImageView: UIImageView!
    @IBOutlet weak var activityIndicatorView: UIActivityIndicatorView!
    @IBOutlet weak var alertView: UIView!
    @IBOutlet weak var buildNowButton: UIButton!
    @IBOutlet weak var skipNowButton: UIButton!
    @IBOutlet weak var headerViewHeightConstraint: NSLayoutConstraint!
    
    private enum SegueIdentifier: String {
        case zipCodeSegue = "ZipCodeSegue"
    }
    
    var state = State.firstLaunch
    
    // MARK: Model & State Types
    
    func withValues(mutations: (inout State) -> Void) {
        
        mutations(&self.state)
        
        stateDidChange()
    }
    
    private func stateDidChange() {
        switch state {
        case .firstLaunch:
            setTranslucentNavigationBar()
            addTuckrBoxTitleView()
            if Env.iPhone4 || Env.iPhone5 {
                headerViewHeightConstraint.constant = Env.iPhone5 ? 300 : 211
                facebookButton.imageEdgeInsets = UIEdgeInsetsMake(3, -150, 0, 0)
            }
            configureHeaderView()
            signUpButton.roundCorner()
            facebookButton.roundCorner()
            buildNowButton.roundCorner()
            skipNowButton.roundCorner()
            
            
            view.layoutIfNeeded()
        case .signUpSuccess():
            activityIndicatorView.stopAnimating()
            performSegueWithIdentifier(SegueIdentifier.zipCodeSegue.rawValue, sender: nil)
        case let .signUpFailure(error):
            activityIndicatorView.stopAnimating()
            showAlert(error.title, message: error.message)
        case .zipCheckPassed:
            alertView.alpha = 0
            UIView.animateWithDuration(0.3) { () -> Void in
                self.alertView.alpha = 1
            }
        }
        
    }
    
    // MARK: View Life Cycle
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.  
        stateDidChange()
    }
    
    override func viewWillAppear(animated: Bool) {
        super.viewWillAppear(animated)
        if let user = Global.currentUser where user.zipCheckPassed == true{
            withValues({ (state) in
                state = .zipCheckPassed
            })
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // MARK: Helper
    
    func configureHeaderView() {
        headerImageView.roundMask([.BottomLeft, .BottomRight], cornerRadii: CGSizeMake(18, 18))
    }
    
    // MARK: - Action
    
    @IBAction func fbButtonClicked(sender: UIButton) {
        Global.fbLoginManager.logInWithReadPermissions(["email"], fromViewController: self) {[weak self] (result, error) -> Void in
            guard let strongSelf = self else { return }
            
            if error != nil {
                strongSelf.showAlert("", message: ErrorMessage.LoginFail.rawValue)
            } else if result.isCancelled {
                
            } else {
                let fbloginresult : FBSDKLoginManagerLoginResult = result
                if(fbloginresult.grantedPermissions.contains("email")) {
                    if((FBSDKAccessToken.currentAccessToken()) != nil) {
                        FBSDKGraphRequest(graphPath: "me", parameters: ["fields": "id, link, name, gender, first_name, last_name, picture.type(large), email"]).startWithCompletionHandler({ (connection, result, error) -> Void in
                            dispatch_async(dispatch_get_main_queue(), { () -> Void in
                                Global.fbLoginManager.logOut()
                            })
                            if error == nil, let email = result.valueForKey("email") as? String, id = result.valueForKey("id") as? String {
                                
                                let fid = "Fb" + id
//                                let fbUsername = result.valueForKey("name") as? String ?? ""
                                
                                let parameters = User.RegisterRequestParameters(email: email, password: fid)
                                User.register(parameters, completion: { [weak self](user, error) in
                                    guard let strongSelf = self else { return }
                                    
                                    Global.currentUser = user
                                    if error == nil {
                                        strongSelf.withValues({ (state) in
                                            state = .signUpSuccess
                                        })
                                    } else {
                                        strongSelf.withValues({ (state) in
                                            state = .signUpFailure(error: error!)
                                        })
                                    }
                                    })
                            } else {
                                if let _ = result.valueForKey("email") as? String {
                                    strongSelf.showAlert("", message: ErrorMessage.GetProfileFail.rawValue)
                                } else {
                                    strongSelf.showAlert(ErrorTitle.facebookAddressMissing.rawValue, message: ErrorMessage.facebookAddressMissing.rawValue)
                                }
                            }
                            })
                    }
                } else {
                    dispatch_async(dispatch_get_main_queue(), { () -> Void in
                        Global.fbLoginManager.logOut()
                        strongSelf.showAlert(ErrorTitle.facebookPermission.rawValue, message: ErrorMessage.facebookPermission.rawValue)
                    })
                }
            }
        }
    }
    
    @IBAction func skipNowButtonTapped(sender: UIButton) {
        navigationController?.popToRootViewControllerAnimated(false)
        Global.rootViewController.state = .login
    }

}
