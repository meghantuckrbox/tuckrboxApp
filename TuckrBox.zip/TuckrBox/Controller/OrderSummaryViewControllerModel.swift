//
//  OrderSummaryViewControllerModel.swift
//  TuckrBox
//
//  Created by Steven Tao on 20/7/2016.
//  Copyright © 2016 ROKO. All rights reserved.
//

import Foundation

struct OrderSummaryViewControllerModel: Equatable {
    
//    var meals: [Meal]
    var orderStatus: Global.OrderStatus {
        didSet {
            createHeaderIndexes()
        }
    }
    
    var headerIndexes: [Int]!
    
    /// Set of default data to be used for the model.
    static var initial: OrderSummaryViewControllerModel {
        return OrderSummaryViewControllerModel(/*meals: [Meal](), */orderStatus: Global.OrderStatus())
    }
    
    // MARK: Initialization
    
    init(orderStatus: Global.OrderStatus) {
        self.orderStatus = orderStatus
        createHeaderIndexes()
    }
    
    mutating func createHeaderIndexes() {
        if orderStatus.keys.count == 0 {
            return 
        }
        
        var indexes = [Int]()
        
        for (index, _) in Global.currentUser!.children.enumerate() {
            if index == 0 {
                indexes.append(0)
            } else {
                let previousChild = Global.currentUser!.children[index - 1]
                let count = orderStatus[previousChild]!.count
                indexes.append(indexes.last! + count + 1)
            }
            
        }
        headerIndexes = indexes
    }
    
    
}

func ==(lhs: OrderSummaryViewControllerModel, rhs: OrderSummaryViewControllerModel) -> Bool {
    return /*lhs.meals == rhs.meals && */lhs.orderStatus == rhs.orderStatus
}


