//: Playground - noun: a place where people can play

import Cocoa

var str = "Hello, playground"

//let a = Int(arc4random_uniform(7) + 1)

//var orders = ["11", "", ""]
//var all = ["" : orders, "q" : orders]
//let count = all.values.reduce(0) { return $0.count }
//
//
//count