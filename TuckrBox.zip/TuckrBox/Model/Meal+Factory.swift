//
//  Meal+Factory.swift
//  TuckrBox
//
//  Created by Steven Tao on 15/7/2016.
//  Copyright © 2016 ROKO. All rights reserved.
//

import SwiftyJSON

extension Meal {
    
    struct GetMealRequestParameters: RequestParameters {
        var user: User
        var child: Child?
        
        func toDictionary() -> [String: AnyObject] {
            var parameters = [String: AnyObject]()
            parameters["id"] = user.id
            return parameters
        }
    }
    
    static func getMeals(paramters: GetMealRequestParameters, completion: (meals: [Meal], error: ResponseError?) -> Void) {
        if Global.isDebug {
            let ingredient1 = Ingredient(image: "Ingredients1", name: "Red Pepper")
            let ingredient2 = Ingredient(image: "Ingredients2", name: "Chickpeas")
            let ingredient3 = Ingredient(image: "Ingredients3", name: "Olive Oil")
            let ingredient4 = Ingredient(image: "Ingredients4", name: "Garlic")
            
            var meal1 = Meal.initial
            meal1.id = "1"
            meal1.name = "Create Your Own Lettuce Wraps"
            meal1.image = "Meal1"
            meal1.ingredients = [ingredient1, ingredient2, ingredient3, ingredient4]
            var meal2 = Meal.initial
            meal2.id = "2"
            meal2.name = "GF Crazy Pasta W/ Red Sauce & Cheese"
            meal2.image = "Meal2"
            meal2.ingredients = [ingredient1, ingredient2, ingredient3, ingredient4]
            var meal3 = Meal.initial
            meal3.id = "3"
            meal3.name = "Marinated Terriaki Chicken"
            meal3.image = "Meal3"
            meal3.ingredients = [ingredient1, ingredient2, ingredient3, ingredient4]
            var meal4 = Meal.initial
            meal4.id = "4"
            meal4.name = "Bangin' BBQ Chicken Sanwich"
            meal4.image = "Meal4"
            meal4.ingredients = [ingredient1, ingredient2, ingredient3, ingredient4]
            let meals = [meal1, meal2, meal3, meal4]
            completion(meals: meals, error: nil)
        }
    }
    
}