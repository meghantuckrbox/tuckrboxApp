//
//  Child+Factory.swift
//  TuckrBox
//
//  Created by Steven Tao on 14/7/2016.
//  Copyright © 2016 ROKO. All rights reserved.
//

import SwiftyJSON

extension Child {

    struct GetChildrenRequestParameters: RequestParameters {
        var user: User
        
        func toDictionary() -> [String: AnyObject] {
            var parameters = [String: AnyObject]()
            parameters["id"] = user.id
            return parameters
        }
    }
    
    struct SaveChildrenRequestParameters: RequestParameters {
        var user: User
        var children: [Child]
        
        func toDictionary() -> [String: AnyObject] {
            var parameters = [String: AnyObject]()
            parameters["id"] = user.id
            return parameters
        }
    }
    
    static func getChildren(parameters: GetChildrenRequestParameters, completion: (children: [Child], error: ResponseError?) -> Void) {
        completion(children: Global.currentUser?.children ?? [Child](), error: nil)
    }
    
    static func saveChildren(parameters: SaveChildrenRequestParameters, completion: (success: Bool, error: ResponseError?) -> Void) {
        Global.updateChildren(parameters.children)
        NSNotificationCenter.defaultCenter().postNotificationName(TuckrBoxNofitication.childUpdate.rawValue, object: nil)
        if Global.isDebug {            
            completion(success: true, error: nil)
        }
    }
    
}