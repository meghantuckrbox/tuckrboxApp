//
//  Child.swift
//  TuckrBox
//
//  Created by Steven Tao on 14/7/2016.
//  Copyright © 2016 ROKO. All rights reserved.
//

import Foundation

struct Child: Equatable {
    
    enum MealPreference: Int  {
        case dairy
        case gluten
//        case vegetarian
//        case soyAllergy
//        case fishShellAllergy
        
        var name: String {
            switch self {
            case .dairy: return "Dairy Free"
            case .gluten: return "Gluten Free"
//            case .vegetarian: return "Vegetarian"
//            case .soyAllergy: return "Soy Allergy"
//            case .fishShellAllergy: return "Fish and Shell Fish Allergy"
            }
        }
    }
    
    enum ChildColor: Int {
        case red
        case blue
        case green
        case yellow
        case purple
//        case ce4e4e4
//        case ca237a4
//        case c0093c4
//        case cff2833
//        case cffffff
//        case c3fbb65
//        case cf7c800
//        
//        var colorCode: Int {
//            switch self {
//            case .ce4e4e4: return 0xe4e4e4
//            case .ca237a4: return 0xa237a4
//            case .c0093c4: return 0x0093c4
//            case .cff2833: return 0xff2833
//            case .cffffff: return 0xffffff
//            case .c3fbb65: return 0x3fbb65
//            case .cf7c800: return 0xf7c800
//            }
//        }
        
        var imageName: String {
            switch self {
            case .red: return "UserIcon1"
            case .blue: return "UserIcon2"
            case .green: return "UserIcon3"
            case .yellow: return "UserIcon4"
            case .purple: return "UserIcon5"
            }
        }
        
        static var random: ChildColor{
            return ChildColor(rawValue: Int(arc4random_uniform(5)))!
        }
        
        static var tolal: Int {
            return 5
        }
        
    }
    
    // MARK: Properties
    var id: String
    var name: String
    var mealPreference: [MealPreference]
    var iconColor: ChildColor
    
    /// Set of default data to be used for the model.
    static var initial: Child {
        Global.nexUserId += 1
        return Child(id: String(Global.nexUserId), name: "", mealPreference: [MealPreference](), iconColor: ChildColor.random)
    }
    
    static var placeHolder: Child {
        return Child(id: "-1", name: "-1", mealPreference: [MealPreference](), iconColor: .red)
    }
}

extension Child: Hashable {
    var hashValue: Int {
        return id.hashValue
    }
}

func ==(lhs: Child, rhs: Child) -> Bool {
    return lhs.id == rhs.id
//    return lhs.name == rhs.name && lhs.mealPreference == rhs.mealPreference && lhs.iconColor == rhs.iconColor
}