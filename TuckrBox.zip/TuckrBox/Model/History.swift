//
//  History.swift
//  TuckrBox
//
//  Created by Steven Tao on 26/7/2016.
//  Copyright © 2016 ROKO. All rights reserved.
//

import Foundation

struct History: Equatable {
    
    typealias Key = String
    
    var orders: [Key: [Order]]
    var dates: [String]
    
    static func getKey(date: NSDate) -> Key {
        return ""
    }
    
    static var initial: History {
        return History(orders: [Key: [Order]](), dates: [String]())
    }
}

func ==(lhs: History, rhs: History) -> Bool {
    return lhs.orders == rhs.orders && lhs.dates == rhs.dates
}