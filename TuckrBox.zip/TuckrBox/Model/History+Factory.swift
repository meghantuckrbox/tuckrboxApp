//
//  History+Factory.swift
//  TuckrBox
//
//  Created by Steven Tao on 3/8/2016.
//  Copyright © 2016 ROKO. All rights reserved.
//

import Foundation
import SwiftyJSON

extension History {
    
    struct GetHistoryRequestParameters: RequestParameters {
        var user: User
        
        func toDictionary() -> [String: AnyObject] {
            var parameters = [String: AnyObject]()
            parameters["id"] = user.id
            return parameters
        }
    }
    
    static func getHistory(paramters: GetHistoryRequestParameters, completion: (history: History, error: ResponseError?) -> Void) {
        if Global.isDebug {
            let ingredient1 = Meal.Ingredient(image: "Ingredients1", name: "Red Pepper")
            let ingredient2 = Meal.Ingredient(image: "Ingredients2", name: "Chickpeas")
            let ingredient3 = Meal.Ingredient(image: "Ingredients3", name: "Olive Oil")
            let ingredient4 = Meal.Ingredient(image: "Ingredients4", name: "Garlic")
            
            var meal1 = Meal.initial
            meal1.id = "1"
            meal1.name = "Create Your Own Lettuce Wraps"
            meal1.image = "Meal1"
            meal1.ingredients = [ingredient1, ingredient2, ingredient3, ingredient4]
            var meal2 = Meal.initial
            meal2.id = "2"
            meal2.name = "GF Crazy Pasta W/ Red Sauce & Cheese"
            meal2.image = "Meal2"
            meal2.ingredients = [ingredient1, ingredient2, ingredient3, ingredient4]
            var meal3 = Meal.initial
            meal3.id = "3"
            meal3.name = "Marinated Terriaki Chicken"
            meal3.image = "Meal3"
            meal3.ingredients = [ingredient1, ingredient2, ingredient3, ingredient4]
            var meal4 = Meal.initial
            meal4.id = "4"
            meal4.name = "Bangin' BBQ Chicken Sanwich"
            meal4.image = "Meal4"
            meal4.ingredients = [ingredient1, ingredient2, ingredient3, ingredient4]
            
            
            let order1 = Order(meal: meal1, count: 2)
            let order2 = Order(meal: meal2, count: 2)
            let order3 = Order(meal: meal3, count: 2)
            let order4 = Order(meal: meal4, count: 2)
            
            let orders = ["Week of 10/17": [order1, order2], "Week of 10/20": [order3, order4], "Week of 10/24": [order1, order4]]
            
            let history = History(orders: orders, dates: ["Week of 10/17", "Week of 10/20", "Week of 10/24"])
            
            completion(history: history, error: nil)
        }
    }
    
}