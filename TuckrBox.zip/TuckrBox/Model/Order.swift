//
//  Order.swift
//  TuckrBox
//
//  Created by Steven Tao on 20/7/2016.
//  Copyright © 2016 ROKO. All rights reserved.
//

import Foundation

struct Order: Equatable {
    
    // MARK: Properties
    var meal: Meal
    var count: Double
    
//    static var initial: Order {
//        return Order(meal: Meal.initial, count: 1)
//    }
}

extension Order: Hashable {
    var hashValue: Int {
        return meal.hashValue ^ count.hashValue
    }
}

func ==(lhs: Order, rhs: Order) -> Bool {
    return lhs.meal == rhs.meal
}