//
//  Plan.swift
//  TuckrBox
//
//  Created by Steven Tao on 20/7/2016.
//  Copyright © 2016 ROKO. All rights reserved.
//

import Foundation

struct Plan: Equatable {
    
    // MARK: Properties
    var numberOfMeal: Int
    
    static var initial: Plan {
        return Plan(numberOfMeal: 2)
    }
}

func ==(lhs: Plan, rhs: Plan) -> Bool {
    return lhs.numberOfMeal == rhs.numberOfMeal
}