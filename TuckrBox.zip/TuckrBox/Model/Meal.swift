//
//  Meal.swift
//  TuckrBox
//
//  Created by Steven Tao on 15/7/2016.
//  Copyright © 2016 ROKO. All rights reserved.
//

import Foundation

struct Meal: Equatable {
    
    struct Ingredient {
        var image: String
        var name: String
        
    }
    
    struct Side {
        var image: String
        var name: String
        var description: String
        
    }
    
    // MARK: Properties
    var id: String
    var name: String
    var image: String
    var ingredients: [Ingredient]
    var nutrition: String
    var sides: [Side]
    
    static var initial: Meal {
        return Meal(id: "", name: "", image: "", ingredients: [Ingredient](), nutrition: "", sides: [Side]())
    }
}

extension Meal: Hashable {
    var hashValue: Int {
        return id.hashValue
    }
}

func ==(lhs: Meal, rhs: Meal) -> Bool {
    return lhs.name == rhs.name
}