//
//  User+Factory.swift
//  Paradise
//
//  Created by Steven Tao on 8/7/2016.
//  Copyright © 2016 ROKO. All rights reserved.
//

import SwiftyJSON

extension User {
    
    struct LoginRequestParameters: RequestParameters {
        var email: String
        var password: String
        
        func toDictionary() -> [String: AnyObject] {
            var parameters = [String: AnyObject]()
            parameters["email"] = email
            parameters["password"] = password
            return parameters
        }
    }
    
    struct RegisterRequestParameters: RequestParameters {
//        var userName: String
        var email: String
        var password: String
        
        func toDictionary() -> [String: AnyObject] {
            var parameters = [String: AnyObject]()
//            parameters["userName"] = userName
            parameters["password"] = password
            parameters["email"] = email
            return parameters
        }
    }
    
    struct CheckZipCodeRequestParameters: RequestParameters {
        var zipCode: String
        
        func toDictionary() -> [String: AnyObject] {
            var parameters = [String: AnyObject]()
            parameters["zipCode"] = zipCode
            return parameters
        }
    }
    
    static func login(paramters: LoginRequestParameters, completion: (user: User?, error: ResponseError?) -> Void) {
        Global.rokoPortalManager.setUserWithName("Test", referralCode: nil, linkShareChannel: nil, completionBlock: { (error) -> Void in
            if error != nil {
                print(error!.description)
            } else {
                print("Success!")
            }
            })
        if Global.isDebug {
            completion(user: User.initial, error: nil)
        }
    }
    
    static func register(paramters: RegisterRequestParameters, completion: (user: User?, error: ResponseError?) -> Void) {
        Global.rokoPortalManager.setUserWithName("Test", referralCode: nil, linkShareChannel: nil, completionBlock: nil)
        if Global.isDebug {
            completion(user: User.initial, error: nil)
        }
    }
    
    static func checkZipCode(paramters: CheckZipCodeRequestParameters, completion: (valid: Bool, error: ResponseError?) -> Void) {
        completion(valid: true, error: nil)
    }
}

extension JSON {
    func toUser() -> User?{
        guard let userName = self["userName"].string, id = self["id"].string else {
            return nil
        }
        return User(id: id, name: userName, children: [Child](), plan: Plan.initial)
    }
}
