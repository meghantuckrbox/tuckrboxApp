//
//  User.swift
//  Paradise
//
//  Created by Steven Tao on 8/7/2016.
//  Copyright © 2016 ROKO. All rights reserved.
//

import Foundation

struct User: Equatable {
    var id: String
    var name: String
    var children: [Child]
    var zipCheckPassed: Bool = false
    var plan: Plan
    var selectedChildIndex = 0
    var selectedChild: Child? {
        if children.count == 0 {
            return nil
        }
        return children[selectedChildIndex]
    }
    
    /// Set of default data to be used for the model.
    static var initial: User {
        if Global.isDebug {
            return Global.debugUser
        }
        return User(id: "", name: "", children: [Child](), plan: Plan.initial)
    }
    
    // MARK: Initialization
    
    init(id: String, name: String, children: [Child], plan: Plan) {
        self.id = id
        self.name = name
        self.children = children
        self.zipCheckPassed = false
        self.selectedChildIndex = 0
        self.plan = plan
    }
    
    
}

func ==(lhs: User, rhs: User) -> Bool {
    return lhs.id == rhs.id
}