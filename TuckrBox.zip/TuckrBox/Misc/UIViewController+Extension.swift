//
//  UIViewController+Extension.swift
//  TuckrBox
//
//  Created by Steven Tao on 12/7/2016.
//  Copyright © 2016 ROKO. All rights reserved.
//

import Foundation
import UIKit

extension UIViewController {
    
    func setTranslucentNavigationBar() {
        navigationController?.navigationBar.setBackgroundImage(UIImage(), forBarMetrics: .Default)
        navigationController?.navigationBar.shadowImage = UIImage()
        navigationController?.navigationBar.translucent = true
        
    }
    
    func addRefreshControl(refreshControl: UIRefreshControl, tableView: UITableView,  action: Selector)  {
        refreshControl.tintColor = UIColor.whiteColor()
        let tableViewController = UITableViewController()
        tableViewController.tableView = tableView
        tableViewController.refreshControl = refreshControl
        refreshControl.addTarget(self, action: action, forControlEvents: UIControlEvents.ValueChanged)
        beginRefreshing(tableView, refreshControl: refreshControl)
    }
    
    func beginRefreshing(tableView: UITableView, refreshControl: UIRefreshControl) {
        if tableView.contentOffset.y == 0 {
            tableView.setContentOffset(CGPointMake(0, tableView.contentOffset.y-refreshControl.frame.size.height), animated: true)
        }
        refreshControl.beginRefreshing()
    }
    
    func addTuckrBoxTitleView() {
        navigationItem.titleView = UIImageView(image: UIImage(named: "NaviLogo"))
    }
    
    func addBackButton() {        
        navigationItem.leftBarButtonItem = UIBarButtonItem(image: UIImage(named: "BackButton"), style: .Plain, target: self, action: #selector(UIViewController.backButtonTapped))
        navigationItem.leftBarButtonItem?.tintColor = UIColor.whiteColor()
    }
    
    func addTapAction() {
        let tapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(UIViewController.dismissKeyboard))
        view.addGestureRecognizer(tapGestureRecognizer)
    }
    
    func dismissKeyboard() {
        view.endEditing(true)
    }
    
    func maintitleView() -> MainTitleView{
        let maintitleView = NSBundle.mainBundle().loadNibNamed(ClassName(MainTitleView), owner: self, options: nil).first as! MainTitleView
        return maintitleView
    }
    
    func addMainTitleView(title: String, action: MainTitleView.TitleViewTappedAction){
        let titleView = maintitleView()
        titleView.titleLabel.text = title
        titleView.titleViewTappedAction = action        
        navigationItem.titleView = titleView
    }
    
    func showAlert(title: String, message: String) {
        let alertController = UIAlertController(title: title, message: message, preferredStyle: .Alert)
        let action = UIAlertAction(title: "OK", style: .Cancel, handler: { (action) in
            self.dismissViewControllerAnimated(true, completion: nil)
        })
        alertController.addAction(action)
        presentViewController(alertController, animated: true, completion: nil)
    }
    
    // MARK: - Action
    
    @IBAction func closeBarButtonTapped(){
        dismissViewControllerAnimated(true, completion: nil)
    }
    
    @IBAction func backButtonTapped(){
        if presentingViewController != nil {
            dismissViewControllerAnimated(true, completion: nil)
        } else {
            navigationController?.popViewControllerAnimated(true)
        }
//        navigationController?.popViewControllerAnimated(true)
    }
    
}