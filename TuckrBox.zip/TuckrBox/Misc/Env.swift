//
//  Env.swift
//  SwiftCharts
//
//  Created by ischuetz on 07/05/15.
//  Copyright (c) 2015 ivanschuetz. All rights reserved.
//

import UIKit

class Env {
  
    static var iPad: Bool {
        return UIDevice.currentDevice().userInterfaceIdiom == .Pad
    }
    
    static var retina: Bool {
        return UIScreen.mainScreen().scale >= 2.0
    }
    
    static var iPhone4: Bool {
        return !Env.iPad && CGRectGetHeight(UIScreen.mainScreen().bounds) == 480.0
    }
    
    static var iPhone5: Bool {
        return !Env.iPad && CGRectGetHeight(UIScreen.mainScreen().bounds) == 568.0
    }
    
    static var iPhone6: Bool {
        return !Env.iPad && CGRectGetHeight(UIScreen.mainScreen().bounds) == 667.0
    }
    
    static var iPhone6Plus: Bool {
        return !Env.iPad && CGRectGetHeight(UIScreen.mainScreen().bounds) == 736.0
    }
    
    static func deviceName() -> String {
        var device = "iPhone6"
        if Env.iPhone4 {
            device = "iPhone4"
        } else if Env.iPhone5 {
            device = "iPhone5"
        } else if Env.iPhone6Plus {
            device = "iPhone6Plus"
        }
        return device
    }
  
}
