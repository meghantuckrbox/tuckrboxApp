//
//  Styles.swift
//  ForceRank
//
//  Created by Steven Tao on 23/9/15.
//  Copyright © 2015 roko. All rights reserved.
//

import Foundation
import UIKit

struct Styles {
    
    static let dateFormatter = NSDateFormatter()
    static let v2DateFormatter = NSDateFormatter()
    static let timeDateFormatter = NSDateFormatter()
    static let weekDayDateFormatter = NSDateFormatter()
    static let weekTimeDateFormatter = NSDateFormatter()
    static let monthFormatter = NSDateFormatter()
    static let monthYearFormatter = NSDateFormatter()
    static let numberFormatter = NSNumberFormatter()
    static let decimalNumberFormatter = NSNumberFormatter()
    static let decimalNumberFormatter_2or0 = NSNumberFormatter()
    static let monthDayDateFormatter = NSDateFormatter()
    static let dateFormatter_MMM_d = NSDateFormatter()
    static let dateFormatter_M_dd_yy = NSDateFormatter()
    
    static let timeZone = "US/Eastern" // EST
    
    static func setupAppearance() {
        UIBarButtonItem.appearance().setTitleTextAttributes([NSForegroundColorAttributeName: UIColor.whiteColor(), NSFontAttributeName:Styles.montserratFont(14)], forState: .Normal)
        UIBarButtonItem.appearance().setTitleTextAttributes([NSForegroundColorAttributeName: UIColor.whiteColor(),  NSFontAttributeName:Styles.montserratFont(14)], forState: .Highlighted)
        UINavigationBar.appearance().titleTextAttributes = [NSForegroundColorAttributeName: UIColor.whiteColor(), NSFontAttributeName:Styles.kreonBoldFont(20)]
//        UIBarButtonItem.appearance().setTitleTextAttributes([NSForegroundColorAttributeName: UIColor.clearColor()], forState: .Highlighted)
//        UINavigationBar.appearance().shadowImage = UIImage()
//        UINavigationBar.appearance().setBackgroundImage(UIImage(), forBarMetrics: .Default)
        
//        UINavigationBar.appearance().backgroundColor = StyleDefaults.blackColor
//        UINavigationBar.appearance().barTintColor = StyleDefaults.blackColor
        
        dateFormatter.locale = NSLocale(localeIdentifier: "en_US_POSIX")
        dateFormatter.timeZone = NSTimeZone(name: timeZone)
        dateFormatter.dateFormat = "yyyy-MM-dd'T'HH:mm:ssZ"
        
        v2DateFormatter.locale = NSLocale(localeIdentifier: "en_US_POSIX")
        v2DateFormatter.timeZone = NSTimeZone(name: timeZone)
        v2DateFormatter.dateFormat = "yyyy-MM-dd HH:mm:ss"
        
        timeDateFormatter.locale = NSLocale(localeIdentifier: "en_US_POSIX")
        timeDateFormatter.timeZone = NSTimeZone(name: timeZone)
        timeDateFormatter.dateFormat = "M/d h:mm a 'ET'"

        weekDayDateFormatter.locale = NSLocale(localeIdentifier: "en_US_POSIX")
        weekDayDateFormatter.timeZone = NSTimeZone(name: timeZone)
        weekDayDateFormatter.dateFormat = "EEE MMM d"
        
        weekTimeDateFormatter.locale = NSLocale(localeIdentifier: "en_US_POSIX")
        weekTimeDateFormatter.timeZone = NSTimeZone(name: timeZone)
        weekTimeDateFormatter.dateFormat = "EEE M/d h:mm a 'ET'"
        
        monthFormatter.locale = NSLocale(localeIdentifier: "en_US_POSIX")
        monthFormatter.timeZone = NSTimeZone(name: timeZone)
        monthFormatter.dateFormat = "MMMM"

        monthYearFormatter.locale = NSLocale(localeIdentifier: "en_US_POSIX")
        monthYearFormatter.timeZone = NSTimeZone(name: timeZone)
        monthYearFormatter.dateFormat = "MMMM-yyyy"
                
        monthDayDateFormatter.locale = NSLocale(localeIdentifier: "en_US_POSIX")
        monthDayDateFormatter.timeZone = NSTimeZone(name: timeZone)
        monthDayDateFormatter.dateFormat = "M/d"
        
        dateFormatter_MMM_d.locale = NSLocale(localeIdentifier: "en_US_POSIX")
        dateFormatter_MMM_d.timeZone = NSTimeZone(name: timeZone)
        dateFormatter_MMM_d.dateFormat = "MMM d"
        
        dateFormatter_M_dd_yy.locale = NSLocale(localeIdentifier: "en_US_POSIX")
        dateFormatter_M_dd_yy.timeZone = NSTimeZone(name: timeZone)
        dateFormatter_M_dd_yy.dateFormat = "M/d/yy"
        
        numberFormatter.usesGroupingSeparator = true
        
        decimalNumberFormatter.usesGroupingSeparator = true
        decimalNumberFormatter.maximumFractionDigits = 2
        decimalNumberFormatter.minimumFractionDigits = 2
        decimalNumberFormatter.minimumIntegerDigits = 1
        
        decimalNumberFormatter_2or0.usesGroupingSeparator = true
        decimalNumberFormatter_2or0.maximumFractionDigits = 2
        decimalNumberFormatter_2or0.minimumFractionDigits = 0
        decimalNumberFormatter_2or0.minimumIntegerDigits = 1

    }
    
    static var redColor: UIColor {
        return UIColor(hexString: 0xef4e4a)
    }
    
    static var yellowColor: UIColor {
        return UIColor(hexString: 0xefc41a)
    }
    
    static var purpleColor: UIColor {
        return UIColor(hexString: 0x914f9e)
    }
    
    static var blueColor: UIColor {
        return UIColor(hexString: 0x1d91c0)
    }
    
    static var greenColor: UIColor {
        return UIColor(hexString: 0x00bf67)
    }
    
    static func kreonBoldFont(fontSize: CGFloat) -> UIFont{
        return UIFont(name: "Kreon-Bold", size: fontSize)!
    }
    
    static func kreonLightFont(fontSize: CGFloat) -> UIFont{
        return UIFont(name: "Kreon-Light", size: fontSize)!
    }
    
    static func montserratFont(fontSize: CGFloat) -> UIFont{
        return UIFont(name: "Montserrat", size: fontSize)!
    }

}