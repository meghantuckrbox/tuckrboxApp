//
//  UIColor+Extension.swift
//  ForceRank
//
//  Created by Steven Tao on 22/9/15.
//  Copyright © 2015 roko. All rights reserved.
//

import UIKit

extension UIColor {
    convenience init(red: Int, green: Int, blue: Int) {
        assert(red >= 0 && red <= 255, "Invalid red component")
        assert(green >= 0 && green <= 255, "Invalid green component")
        assert(blue >= 0 && blue <= 255, "Invalid blue component")
        
        self.init(red: CGFloat(red) / 255.0, green: CGFloat(green) / 255.0, blue: CGFloat(blue) / 255.0, alpha: 1.0)
    }
    
    convenience init(hexString:Int) {
        self.init(red:(hexString >> 16) & 0xff, green:(hexString >> 8) & 0xff, blue:hexString & 0xff)
    }
}