//
//  UIViewController+RefreshHeader.swift
//  TuckrBox
//
//  Created by Steven Tao on 14/7/2016.
//  Copyright © 2016 ROKO. All rights reserved.
//

import Foundation
import UIKit


extension UIViewController {
    
//    func addRefreshControl(refreshControl: UIRefreshControl, tableView: UITableView,  action: Selector)  {
//        refreshControl.tintColor = UIColor.whiteColor()
//        let tableViewController = UITableViewController()
//        tableViewController.tableView = tableView
//        tableViewController.refreshControl = refreshControl
//        refreshControl.addTarget(self, action: action, forControlEvents: UIControlEvents.ValueChanged)
//    }
//    
//    func beginRefreshing(tableView: UITableView) {
//        if tableView.contentOffset.y == 0 {
//            tableView.setContentOffset(CGPointMake(0, tableView.contentOffset.y-refreshControl.frame.size.height), animated: true)
//        }
//        refreshControl.beginRefreshing()
//    }
}