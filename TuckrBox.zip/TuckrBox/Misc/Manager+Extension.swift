//
//  Manager+Extension.swift
//  ForceRank
//
//  Created by Steven Tao on 9/10/15.
//  Copyright © 2015 roko. All rights reserved.
//

import Foundation
import Alamofire

func URLRequest(
    method: Alamofire.Method,
    _ URLString: URLStringConvertible,
    headers: [String: String]? = nil,
    cachePolicy: NSURLRequestCachePolicy,
    timeoutInterval: NSTimeInterval = 60
    )
    -> NSMutableURLRequest
{
    let urlString = URLString
    let mutableURLRequest = NSMutableURLRequest(URL: NSURL(string: urlString.URLString)!, cachePolicy: cachePolicy, timeoutInterval: timeoutInterval)
    mutableURLRequest.HTTPMethod = method.rawValue
    
    if let headers = headers {
        for (headerField, headerValue) in headers {
            mutableURLRequest.setValue(headerValue, forHTTPHeaderField: headerField)
        }
    }
    
    return mutableURLRequest
}

extension Manager {
    public func request(
        method: Alamofire.Method,
        _ URLString: URLStringConvertible,
        parameters: [String: AnyObject]? = nil,
        encoding: ParameterEncoding = .URL,
        headers: [String: String]? = nil,
        cachePolicy: NSURLRequestCachePolicy = .UseProtocolCachePolicy,
        timeoutInterval: NSTimeInterval = 60
        )
        -> Request
    {
        let urlString = URLString
        let mutableURLRequest = URLRequest(method, urlString, headers: headers, cachePolicy: cachePolicy)
        let encodedURLRequest = encoding.encode(mutableURLRequest, parameters: parameters).0
        return request(encodedURLRequest)
    }
}
