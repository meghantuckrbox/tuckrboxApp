//
//  UIViewController+Navigation.swift
//  TuckrBox
//
//  Created by Steven Tao on 4/8/2016.
//  Copyright © 2016 ROKO. All rights reserved.
//

import Foundation
import UIKit

extension UIViewController {

    func gotoMealDetailPage(meal: Meal) {
        let storyboard = UIStoryboard(name: "Meal", bundle: nil)
        let mealDetailViewController = storyboard.instantiateViewControllerWithIdentifier(ClassName(MealDetailViewController)) as! MealDetailViewController
        mealDetailViewController.model = MealDetailViewControllerModel(meal: meal)
        navigationController?.pushViewController(mealDetailViewController, animated: true)
    }
    
    func goToOrderSummary(status: Global.OrderStatus) {
        let storyboard = UIStoryboard(name: "Meal", bundle: nil)
        let orderSummaryViewController = storyboard.instantiateViewControllerWithIdentifier(ClassName(OrderSummaryViewController)) as! OrderSummaryViewController
        orderSummaryViewController.model = OrderSummaryViewControllerModel(orderStatus: status)
        navigationController?.pushViewController(orderSummaryViewController, animated: true)
    }
    
    func goToManageFamily(action: FamilyViewController.SaveAction) {
        let storyboard = UIStoryboard(name: "SignUp", bundle: nil)
        let familyViewController = storyboard.instantiateViewControllerWithIdentifier(ClassName(FamilyViewController)) as! FamilyViewController
        familyViewController.saveAction = action
        familyViewController.state = FamilyViewController.State.buildFamily
        let naviCtrl = UINavigationController(rootViewController: familyViewController)
        presentViewController(naviCtrl, animated: true, completion: nil)
    }
    
}