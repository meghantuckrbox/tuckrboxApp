//
//  RequestParameters.swift
//  Paradise
//
//  Created by Steven Tao on 8/7/2016.
//  Copyright © 2016 ROKO. All rights reserved.
//

protocol RequestParameters {
    func toDictionary() -> [String: AnyObject]
}
