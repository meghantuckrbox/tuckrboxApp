//
//  Global.swift
//  Paradise
//
//  Created by Steven Tao on 8/7/2016.
//  Copyright © 2016 ROKO. All rights reserved.
//

import Foundation
import UIKit
import Alamofire
import SwiftyJSON
import FBSDKLoginKit

enum ErrorMessage: String {
    case facebookAddressMissing = "An email address is missing in your Facebook account. Please enter an email in your profile or create a Forcerank account using email."
    case facebookPermission = "Please grant the email permission."
    case MissingValue = "Please enter all required values."
    case PasswordNotMatch = "New password and confirm new password don't match, let's try that again."
    case IncorrectCurrentPassword = "Doesn't look like that's your current password, password must be at least 8 characters long and include one number and one letter"
    case LoginFail = "Login fail."
    case GetProfileFail = "Get profile fail."
    case InvalidExpDate = "Invalid expiration date."
    case NetworkError = "Apologies but we have experienced an unexpected error. Please close Forcerank and reopen the app. If you continue to have this issue, please contact us at support@forcerank.com."
    case NetworkErrorTitle = "Forcerank Unavailable"
    case AgreementNotAgree = "You must agree to Forcerank Terms & Conditions as well as acknowledge that you are over the age of 18 in order to create an account with Forcerank."
    case CreateAccountErrorTitle = "Account Creation Error"
}

enum ErrorTitle: String {
    case facebookPermission = "Facebook Email Permission Required"
    case facebookAddressMissing = "Facebook Email Address Required"
}

enum TuckrBoxNofitication: String{
    case mealUpdate = "AddedFundNotificationKey"
    case showMealSelection = "ShowMealSelectionNotificationKey"
    case refreshHistory = "RefreshHistoryNotificationKey"
    case refreshShoppingBag = "RefreshShoppingBagNotificationKey"
    case childUpdate = "ChildUpdateNotificationKey"
}

func errorContent(response: Response<AnyObject, NSError>) -> ResponseError {
    var message = ""
    var title = ""
    if let value = response.result.value {
        let json = JSON(value)
        if let messages = json.array {
            for (index, subJson) in messages.enumerate() {
                let prefix = messages.count == 1 ? "" : "\(index + 1). "
                message += prefix + subJson["message"].stringValue + "\n"
                title = subJson["title"].stringValue
            }
        } else {
            message = json["message"].stringValue
            title = json["title"].stringValue
        }
    } else {
        message = "Server error."
        title = "Error"
    }
    return (message, title)
}

func showAllFontsName() {
    for familyName in UIFont.familyNames() {
        if UIFont.fontNamesForFamilyName(familyName).count > 0 {
            print(familyName)
        }
    }
}

func stringForValue(value: Int) -> String {
    let characters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    
    return characters.substringFromIndex(characters.startIndex.advancedBy(min(value, 26))).substringToIndex(characters.startIndex.advancedBy(1))
}

func ==<K1: Hashable, K2: Hashable>(lhs: [K1: [K2]], rhs: [K1: [K2]]) -> Bool {
    if lhs.count != rhs.count { return false }
    
    for (key, lhsub) in lhs {
        if let rhsub = rhs[key] {
            if lhsub != rhsub {
                return false
            }
        } else {
            return false
        }
    }
    
    return true
}

func ==<T: Equatable, K1: Hashable, K2: Hashable>(lhs: [K1: [K2: T]], rhs: [K1: [K2: T]]) -> Bool {
    if lhs.count != rhs.count { return false }
    
    for (key, lhsub) in lhs {
        if let rhsub = rhs[key] {
            if lhsub != rhsub {
                return false
            }
        } else {
            return false
        }
    }
    
    return true
}


class Global {
    
    typealias OrderStatus = [Child: [Order]]
    
    static var currentUser: User?
    static var currentOrderStatus: OrderStatus?
    static var currentOrderCount: Int {
        guard let status = currentOrderStatus else { return 0 }
        
        var count = 0
        for value in status.values {
            count += value.count
        }
        return count
    }
    static var nexUserId: Int = 10
    static var isDebug: Bool = true
    static var rootViewController : RootViewController!
    static var debugUser: User {
        var child1 = Child.initial
        child1.name = "Name 1"
        var child2 = Child.initial
        child2.name = "Name 2"
        var child3 = Child.initial
        child3.name = "Name 3"
        var child4 = Child.initial
        child4.name = "Name 4"
        return User(id: "1", name: "steve", children: [child1, child2, child3, child4], plan: Plan.initial)
//        return User(id: "1", name: "steve", children: [Child](), plan: Plan.initial)
    }
    static var isLogin: Bool {
        return Global.rootViewController.state != .signUp
    }
    
    static func updateChildren(children: [Child]) {
        Global.currentUser?.children = children
        if var status = Global.currentOrderStatus {
            for child in children {
                if !status.keys.contains(child) {
                    status[child] = [Order]()
                }
            }
            Global.currentOrderStatus = status
        }
    }
    
    static let fbLoginManager = FBSDKLoginManager()
    
    static let rokoPortalManager = ROKOComponentManager.sharedManager().portalManager()
    
    static var rokoReferralCode: String? {
        return rokoPortalManager.userInfo?.referralCode
    }
    
    static var rokoLink: ROKOLink?
    
    static var rokoLinkURL: String?
    
    static var rokoLinkId: Double?
    
    static var rokoLinkReferralCode: String? {
        get {
            return NSUserDefaults.standardUserDefaults().stringForKey("RokoLinkReferralCode")
        }
        set {
            if newValue == nil {
                NSUserDefaults.standardUserDefaults().removeObjectForKey("RokoLinkReferralCode")
            } else {
                NSUserDefaults.standardUserDefaults().setObject(newValue, forKey: "RokoLinkReferralCode")
            }
        }
    }
    
    static var rokoLinkShareChannel: String? {
        get {
            return NSUserDefaults.standardUserDefaults().stringForKey("RokoLinkShareChannel")
        }
        set {
            if newValue == nil {
                NSUserDefaults.standardUserDefaults().removeObjectForKey("RokoLinkShareChannel")
            } else {
                NSUserDefaults.standardUserDefaults().setObject(newValue, forKey: "RokoLinkShareChannel")
            }
        }
    }
    
    static var firstLaunched: Bool {
        get {
            return NSUserDefaults.standardUserDefaults().boolForKey("firstLaunched") ?? false
        }
        set {
            NSUserDefaults.standardUserDefaults().setBool(newValue, forKey: "firstLaunched")
        }
    }
    
    static let rokoLinkManager = ROKOLinkManager()
    
    static let rokoPromo = ROKOPromo()
    
    static var rokoInviteMessage: ROKOInviteMessage?
    
//    static let rokoComponentManager = ROKOComponentManager()
    
    static let accountKeychainItemWrapper = KeychainItemWrapper(identifier: "Account", accessGroup: nil)
    
}