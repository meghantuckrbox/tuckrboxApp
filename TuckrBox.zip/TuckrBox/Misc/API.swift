//
//  API.swift
//  Paradise
//
//  Created by Steven Tao on 5/7/2016.
//  Copyright © 2016 ROKO. All rights reserved.
//

import Alamofire
import SwiftyJSON

typealias APICompletionHandler = (Response<AnyObject, NSError>, isCache: Bool) -> Void
typealias SuccessHandler = (Response<AnyObject, NSError>, isCache: Bool) -> Void
typealias FailureHandler = (HTTPError, errorMessage: ResponseError) -> Void
typealias ResponseError = (message: String, title: String)
typealias AuthErrorHandler = (statusCode: Int) -> Void
typealias ResponseErrorParser = (response: Response<AnyObject, NSError>) -> ResponseError

enum HTTPError: ErrorType {
    case Unknown
    case Authentication
    case Conflict
    case NotFound
}

class API {
    
    static let baseAPIUrl = "https://api.forcerank.com/"
    static let sharedInstance = API()
    private let HTTPClient: Alamofire.Manager!
    
    var authErrorHandler: AuthErrorHandler?
    var responseErrorParser: ResponseErrorParser!
    var userName = ""
    var password = ""
    var isNoNetwork = false
    
    private init() {
        // Create a shared URL cache
        let memoryCapacity = 500 * 1024 * 1024; // 500 MB
        let diskCapacity = 500 * 1024 * 1024; // 500 MB
        let cache = NSURLCache(memoryCapacity: memoryCapacity, diskCapacity: diskCapacity, diskPath: "shared_cache")
        NSURLCache.setSharedURLCache(cache)
        
        // Create a custom configuration
        let configuration = NSURLSessionConfiguration.defaultSessionConfiguration()
        let defaultHeaders = Alamofire.Manager.sharedInstance.session.configuration.HTTPAdditionalHeaders
        configuration.HTTPAdditionalHeaders = defaultHeaders
        configuration.requestCachePolicy = .UseProtocolCachePolicy // this is the default
        configuration.URLCache = cache
        
        // Create your own manager instance that uses your custom configuration
        HTTPClient = Alamofire.Manager(configuration: configuration)
        
        responseErrorParser = {
            (response: Response<AnyObject, NSError>) -> ResponseError in
            var message = ""
            var title = ""
            if let value = response.result.value {
                let json = JSON(value)
                if let messages = json.array {
                    for (index, subJson) in messages.enumerate() {
                        let prefix = messages.count == 1 ? "" : "\(index + 1). "
                        message += prefix + subJson["message"].stringValue + "\n"
                        title = subJson["title"].stringValue
                    }
                } else {
                    message = json["message"].stringValue
                    title = json["title"].stringValue
                }
            } else {
                message = "Server error."
                title = "Error"
            }
            return (message, title)
        }
        
    }
    
    func request(method: Alamofire.Method,
                 _ URLString: URLStringConvertible,
                   parameters: AnyObject? = nil,
                   encoding: ParameterEncoding = .URL,
                   headers: [String: String]? = nil,
                   timeoutInterval: NSTimeInterval = 60,
                   cachePolicy: NSURLRequestCachePolicy = .UseProtocolCachePolicy,
                       authentication: Bool = true,
                       user: String = API.sharedInstance.userName,
                       password : String = API.sharedInstance.password,
                       completionHandler: (Response<AnyObject, NSError>, isCache: Bool) -> Void){
        
        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0)) { [unowned self]() -> Void in
            var _headers: [String: String]?
            if authentication {
                _headers = headers ?? [String: String]()
                let plainString = "\(user):\(password)" as NSString
                let plainData = plainString.dataUsingEncoding(NSUTF8StringEncoding)
                let base64String = plainData?.base64EncodedStringWithOptions(NSDataBase64EncodingOptions(rawValue: 0))
                _headers!["Authorization"] = "Basic " + base64String!
            } else {
                _headers = headers ?? [String: String]()
            }
            _headers!["X-Device"] = Env.deviceName()
            
            let cacheRequest: Request
            let request: Request
            
            if let _parameters = parameters as? [String: AnyObject] {
                cacheRequest = self.HTTPClient.request(method, URLString, parameters: _parameters, encoding: encoding, cachePolicy:.ReturnCacheDataDontLoad, headers:_headers, timeoutInterval: timeoutInterval)
                request = self.HTTPClient.request(method, URLString, parameters: _parameters, encoding: encoding, cachePolicy:.ReloadIgnoringLocalCacheData, headers:_headers, timeoutInterval: timeoutInterval)
            } else if let _parameters = parameters as? [AnyObject]{
                let cacheMutableURLRequest = URLRequest(method, URLString, headers: _headers, cachePolicy: .ReturnCacheDataDontLoad)
                cacheMutableURLRequest.HTTPBody = try! NSJSONSerialization.dataWithJSONObject(_parameters, options: [])
                let mutableURLRequest = URLRequest(method, URLString, headers: _headers, cachePolicy: .ReloadIgnoringLocalCacheData)
                mutableURLRequest.HTTPBody = try! NSJSONSerialization.dataWithJSONObject(_parameters, options: [])
                
                cacheRequest = self.HTTPClient.request(cacheMutableURLRequest)
                request = self.HTTPClient.request(mutableURLRequest)
            } else {
                cacheRequest = self.HTTPClient.request(method, URLString, parameters: nil, encoding: encoding, cachePolicy:.ReturnCacheDataDontLoad, headers:_headers, timeoutInterval: timeoutInterval)
                request = self.HTTPClient.request(method, URLString, parameters: nil, encoding: encoding, cachePolicy:.ReloadIgnoringLocalCacheData, headers:_headers, timeoutInterval: timeoutInterval)
            }
            
            var _cachePolicy = cachePolicy
            if self.isNoNetwork {
                _cachePolicy = .ReturnCacheDataDontLoad
            }
            
            var loadCache = true
            var loadServer = true
            var loadCacheOrServer = false
            var validateCache = false
            
            switch _cachePolicy {
            case .UseProtocolCachePolicy: break
            case .ReturnCacheDataElseLoad: loadCacheOrServer = true
            case .ReturnCacheDataDontLoad: loadServer = false
            case .ReloadRevalidatingCacheData: validateCache = true
            case .ReloadIgnoringLocalCacheData, .ReloadIgnoringLocalAndRemoteCacheData: loadCache = false
            }
            
            if loadCache {
                cacheRequest.responseJSON(completionHandler: { response in
                    var isValidCache = response.result.isSuccess
                    if validateCache {
                        isValidCache = self.isValidCache(response)
                    }
                    
                    if isValidCache || self.isNoNetwork {
                        completionHandler(response, isCache: self.isNoNetwork)
                    }
                    
                    if loadCacheOrServer && !isValidCache || !loadCacheOrServer && loadServer {
                        request.responseJSON(completionHandler: { response in
                            completionHandler(response, isCache: false)
                        })
                    }
                })
            } else {
                request.responseJSON(completionHandler: { response in
                    completionHandler(response, isCache: false)
                })
            }
        }
    }
    
    func isValidCache(response: Response<AnyObject, NSError>) -> Bool {
        return response.result.isSuccess
    }
    
}

private extension API {
    static func validateResponse(response: Response<AnyObject, NSError>, ignoreAuthError: Bool = false) throws {
        guard let response = response.response  else {
            throw HTTPError.Unknown
        }
        
        switch response.statusCode {
        case 200...300: return
        case 401, 403:
            if !ignoreAuthError {
                API.sharedInstance.authErrorHandler?(statusCode: response.statusCode)
            }
            throw HTTPError.Authentication
        case 404: throw HTTPError.NotFound
        case 409: throw HTTPError.Conflict
        default: throw HTTPError.Unknown
        }
        
    }
    
    func handleResponse(response: Response<AnyObject, NSError>, isCache: Bool, success: SuccessHandler, failure:FailureHandler) {
        do {
            try API.validateResponse(response)
            success(response, isCache: isCache)
        } catch HTTPError.Authentication {
            failure(HTTPError.Authentication, errorMessage: responseErrorParser(response: response))
        } catch HTTPError.NotFound{
            failure(HTTPError.NotFound, errorMessage: responseErrorParser(response: response))
        } catch HTTPError.Conflict{
            failure(HTTPError.Conflict, errorMessage: responseErrorParser(response: response))
        } catch {
            failure(HTTPError.Unknown, errorMessage: responseErrorParser(response: response))
        }
    }
}


