//
//  UILabel+Extension.swift
//  ForceRank
//
//  Created by Steven Tao on 16/12/15.
//  Copyright © 2015 roko. All rights reserved.
//

import Foundation

extension UILabel {
    func setFontSize(fontSize: CGFloat) {
        self.font = self.font.fontWithSize(fontSize)
    }
}