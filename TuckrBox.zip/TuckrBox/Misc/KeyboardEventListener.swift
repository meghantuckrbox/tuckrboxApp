//
//  UIViewController+Keyboard.swift
//  TuckrBox
//
//  Created by Steven Tao on 12/7/2016.
//  Copyright © 2016 ROKO. All rights reserved.
//

import Foundation
import UIKit

@objc protocol KeyboardEventListener {
    weak var activeTextView: UITextField? {get set}
    weak var viewTopConstraint: NSLayoutConstraint? {get set}

    optional func listenKeyboardEventNotification()    
}


extension KeyboardEventListener where Self: UIViewController {
    
    func listenKeyboardEventNotification() {
        let handleKeyboardSizeChangeNotification = {[weak self](notification : NSNotification) -> Void in
            guard let strongSelf = self else { return }
            
            if let userInfo = notification.userInfo {
                if let keyboardHeight = userInfo[UIKeyboardFrameEndUserInfoKey]?.CGRectValue.size.height {
                    let offset = strongSelf.view.frame.size.height - keyboardHeight - 10.0
                    if let textField = strongSelf.activeTextView {
                        let rect = strongSelf.view.convertRect(textField.bounds, fromView: textField)
                        if CGRectGetMaxY(rect) > offset {
                            let diff = CGRectGetMaxY(rect) - offset
                            strongSelf.viewTopConstraint?.constant = diff * -1
                            UIView.animateWithDuration(0.3, animations: { () -> Void in
                                strongSelf.view.layoutIfNeeded()
                            })
                        }
                    }
                }
            }
            
        }
        
        let handleKeyboardWillHideNotification = {[weak self](notification : NSNotification) -> Void in
            guard let strongSelf = self else { return }
            strongSelf.viewTopConstraint?.constant = 0
            UIView.animateWithDuration(0.3, animations: { () -> Void in
                strongSelf.view.layoutIfNeeded()
            })
        }
        
        let mainQueue = NSOperationQueue.mainQueue()
        NSNotificationCenter.defaultCenter().addObserverForName(UIKeyboardWillShowNotification, object: nil, queue: mainQueue, usingBlock: handleKeyboardSizeChangeNotification)
        NSNotificationCenter.defaultCenter().addObserverForName(UIKeyboardWillChangeFrameNotification, object: nil, queue: mainQueue, usingBlock: handleKeyboardSizeChangeNotification)
        NSNotificationCenter.defaultCenter().addObserverForName(UIKeyboardWillHideNotification, object: nil, queue: mainQueue, usingBlock: handleKeyboardWillHideNotification)
        
    }
    
}

//extension UIViewController: UITextFieldDelegate {
//    // MARK: - UITextFieldDelegate
//    
//    public func textFieldDidBeginEditing(textField: UITextField) {
//        if self is KeyboardEventListener {
//            self.updateActiveTextView(textField)
//        }
////        if respondsToSelector(#selector(KeyboardEventListener.updateActiveTextView(_:))) {
////            performSelector(#selector(KeyboardEventListener.updateActiveTextView(_:)), withObject: textField)
////        }
//    }
//    
//    public func textFieldDidEndEditing(textField: UITextField) {
//        if respondsToSelector(#selector(KeyboardEventListener.updateActiveTextView(_:))) {
//            performSelector(#selector(KeyboardEventListener.updateActiveTextView(_:)), withObject: nil)
//        }
//    }
//    
//    public func textFieldShouldReturn(textField: UITextField) -> Bool {
//        if respondsToSelector(#selector(KeyboardEventListener.updateActiveTextView(_:))) {
//            performSelector(#selector(KeyboardEventListener.updateActiveTextView(_:)), withObject: nil)
//        }
//        return true
//    }
//}

