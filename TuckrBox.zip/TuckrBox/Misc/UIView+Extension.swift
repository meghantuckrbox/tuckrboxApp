//
//  UIView+Extension.swift
//  TuckrBox
//
//  Created by Steven Tao on 12/7/2016.
//  Copyright © 2016 ROKO. All rights reserved.
//

import Foundation
import UIKit

func ClassName(aClass: AnyObject) -> String{
    return NSStringFromClass(aClass.classForCoder).componentsSeparatedByString(".").last!
}

extension UIView {
    
    func loadNibNamed(name: String!, view: UIView!) {
        NSBundle.mainBundle().loadNibNamed(name, owner: self, options: nil)
    }
    
    func sizeFit(subView: UIView) {
        subView.translatesAutoresizingMaskIntoConstraints = false
        let leadingContraints = NSLayoutConstraint(item: subView, attribute:
            .Leading, relatedBy: .Equal, toItem: self,
                      attribute: .Leading, multiplier: 1.0,
                      constant: 0.0)
        let trailingContraints = NSLayoutConstraint(item: subView, attribute:
            .Trailing, relatedBy: .Equal, toItem: self,
                       attribute: .Trailing, multiplier: 1.0,
                       constant: 0.0)
        let topContraints = NSLayoutConstraint(item: subView, attribute:
            .Top, relatedBy: .Equal, toItem: self,
                  attribute: .Top, multiplier: 1.0,
                  constant: 0.0)
        let bottomContraints = NSLayoutConstraint(item: subView, attribute:
            .Bottom, relatedBy: .Equal, toItem: self,
                     attribute: .Bottom, multiplier: 1.0,
                     constant: 0.0)
        
        addConstraints([leadingContraints, trailingContraints, topContraints, bottomContraints])
        
        layoutIfNeeded()
    }

    
    func roundCorner(showShadow: Bool = true) {
        layer.cornerRadius = CGRectGetHeight(frame)/2
        layer.masksToBounds = false
        if showShadow {
            layer.shadowOffset = CGSizeMake(2, 2)
            layer.shadowColor = UIColor.blackColor().CGColor
            layer.shadowOpacity = 0.2
            layer.shadowRadius = 0.0
        }
    }
    
    func roundViewCorner(showShadow: Bool = true) {
        layer.cornerRadius = CGRectGetHeight(frame)/2
        layer.masksToBounds = true
        if showShadow {
            layer.shadowOffset = CGSizeMake(2, 2)
            layer.shadowColor = UIColor.blackColor().CGColor
            layer.shadowOpacity = 0.2
            layer.shadowRadius = 0.0
        }
    }
    
    func loadFromNib() -> UIView? {
        guard let view = NSBundle.mainBundle().loadNibNamed(ClassName(self), owner: self, options: nil)[0] as? UIView  else { return nil }
        addSubview(view)
        sizeFit(view)
        return view
    }
    
    func round(corners: UIRectCorner, cornerRadii: CGSize) {
        let maskPath = UIBezierPath(roundedRect: self.bounds, byRoundingCorners: corners, cornerRadii: cornerRadii)
        let maskLayer = CAShapeLayer()
        maskLayer.frame = self.bounds
        maskLayer.path  = maskPath.CGPath
        maskLayer.fillColor   = UIColor.whiteColor().CGColor
        self.layer.insertSublayer(maskLayer, atIndex: 0)
    }
    
    func roundMask(corners: UIRectCorner, cornerRadii: CGSize) {
        let maskPath = UIBezierPath(roundedRect: bounds, byRoundingCorners: corners, cornerRadii: cornerRadii)
        let maskLayer = CAShapeLayer()
        maskLayer.frame = bounds
        maskLayer.path  = maskPath.CGPath
        layer.mask = maskLayer
    }
}
