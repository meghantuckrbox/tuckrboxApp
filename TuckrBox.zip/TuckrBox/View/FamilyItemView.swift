//
//  FamilyItemView.swift
//  TuckrBox
//
//  Created by Steven Tao on 13/7/2016.
//  Copyright © 2016 ROKO. All rights reserved.
//

import UIKit

class FamilyItemView: UIView {

    typealias Model = FamilyItemViewModel
    typealias ModelDidChangeAction = (familyItemView: FamilyItemView, model: Model) -> Void
    typealias HeaderDidTappedAction = (familyItemView: FamilyItemView) -> Void
    
    // MARK: Properties
    @IBOutlet weak var iconView: UIView!
    @IBOutlet weak var iconImageView: UIImageView!
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var arrowImageView: UIImageView!
    @IBOutlet weak var editView: UIView!
    @IBOutlet weak var editStackView: UIStackView!
    @IBOutlet weak var topStackViewHeight: NSLayoutConstraint!
    @IBOutlet weak var nameTextField: RoundTextFieldView!
    @IBOutlet var checkboxViews: [CheckboxView]!
    @IBOutlet weak var collectionView: UICollectionView!
    var modelDidChangeAction: ModelDidChangeAction?
    var headerDidTappedAction: HeaderDidTappedAction?
    
    var model = Model.initial
    var state = State.firstLaunch
    
    
    // MARK: Model & State Types
    
    func withValues(mutations: (inout Model, inout State) -> Void) {
        
        mutations(&self.model, &self.state)
        
        modelDidChange()
        stateDidChange()
    }
    
    private func modelDidChange() {
        if model.child.name.isEmpty {
            model.child.name = "Child \(stringForValue(model.index)) Name"
            modelDidChangeAction?(familyItemView: self, model: model)
        }
        nameLabel.text = model.child.name
//        iconView.backgroundColor = UIColor(hexString: model.child.iconColor.colorCode)
        iconImageView.image = UIImage(named: model.child.iconColor.imageName)
        backgroundColor = UIColor(hexString: model.backgroundColor.colorCode)
        for checkBoxView in checkboxViews {
            checkBoxView.checkBoxButton.selected = false
        }
        for preference in model.child.mealPreference {
            checkboxViews[preference.rawValue].checkBoxButton.selected = true
        }
        collectionView.reloadData()
    }
    
    private func stateDidChange() {
        switch state {
        case .firstLaunch:
            let cellIdentifier = ClassName(IDIconCollectionViewCell)
            collectionView.registerNib(UINib(nibName: cellIdentifier, bundle: nil), forCellWithReuseIdentifier: cellIdentifier)
            nameTextField.placeHolder = "Enter your child's name here"
            nameTextField.textAlignment = .Left
            nameTextField.hideImageView = true
            iconView.layer.borderColor = UIColor.blackColor().CGColor
            iconView.layer.borderWidth = 1
            
            for (index, checkBox) in checkboxViews.enumerate() {
                checkBox.nameLabel.text = Child.MealPreference(rawValue: index)!.name
                checkBox.checkBoxButton.tag = index
                checkBox.checkBoxButton.addTarget(self, action: #selector(FamilyItemView.checkBoxTapped(_:)), forControlEvents: .TouchUpInside)
            }
            state = State.viewing(showArrow: true)
        case let .viewing(showArrow):
            if Global.currentOrderStatus != nil {
                arrowImageView.hidden = true
            } else {
                arrowImageView.hidden = !showArrow
            }
            editStackView.hidden = true
            topStackViewHeight.constant = state.topStackViewHeight            
        case .editing:
            arrowImageView.hidden = true
            editStackView.hidden = false
        case let .expand(flag):
            arrowImageView.hidden = true
            editStackView.hidden = !flag
            topStackViewHeight.constant = state.topStackViewHeight
        }
    }
    
    // MARK: View Life Cycle
    
    override func awakeFromNib() {
        super.awakeFromNib()
        loadFromNib()
        stateDidChange()
    }
    
    // MARK: - Helper
    
    func setModelDidChangeAction(action: ModelDidChangeAction) {
        modelDidChangeAction = action
    }
    
    func setHeaderViewDidTappedAction(action: HeaderDidTappedAction) {
        headerDidTappedAction = action
    }
    
    
    
    // MARK: - Action
    
    @IBAction func checkBoxTapped(sender: UIButton){
        var newModel = model
        if let preference = Child.MealPreference(rawValue: sender.tag) {
            if newModel.child.mealPreference.contains(preference) {
                newModel.child.mealPreference.removeAtIndex(newModel.child.mealPreference.indexOf(preference)!)
            } else {
                newModel.child.mealPreference.append(preference)
            }
            modelDidChangeAction?(familyItemView: self, model: newModel)
        }
    }
    
    @IBAction func headerTapped() {
        headerDidTappedAction?(familyItemView: self)
    }

}

// MARK: - UICollectionViewDataSource, UICollectionViewDelegate, UICollectionViewDelegateFlowLayout

extension FamilyItemView : UICollectionViewDataSource, UICollectionViewDelegate, UICollectionViewDelegateFlowLayout {
    
    func collectionView(collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return state == .firstLaunch ? 0 : Child.ChildColor.tolal
    }
    
    func collectionView(collectionView: UICollectionView, cellForItemAtIndexPath indexPath: NSIndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCellWithReuseIdentifier(ClassName(IDIconCollectionViewCell), forIndexPath: indexPath) as! IDIconCollectionViewCell
        if let color = Child.ChildColor(rawValue: indexPath.row) {
//            cell.iconView.backgroundColor = UIColor(hexString: color.colorCode)
            cell.iconView.image = UIImage(named: color.imageName)
            cell.selectedView.hidden = !(model.child.iconColor == color)
        }
        return cell
    }
    
    func collectionView(collectionView: UICollectionView, didSelectItemAtIndexPath indexPath: NSIndexPath) {
        if let color = Child.ChildColor(rawValue: indexPath.row) {
            if model.child.iconColor != color {
                model.child.iconColor = color
//                if color.colorCode == model.backgroundColor.colorCode {
//                    model.backgroundColor = FamilyItemViewModel.generateBackgroundColor(indexPath.row)
//                }
                modelDidChangeAction?(familyItemView: self, model: model)
            }
        }
    }
}
