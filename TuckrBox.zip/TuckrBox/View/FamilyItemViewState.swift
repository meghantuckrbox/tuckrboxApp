//
//  FamilyItemViewState.swift
//  TuckrBox
//
//  Created by Steven Tao on 13/7/2016.
//  Copyright © 2016 ROKO. All rights reserved.
//

import Foundation
import UIKit

extension FamilyItemView {
    enum State : Equatable{
        case firstLaunch
        case viewing(showArrow: Bool)
        case editing
        case expand(flag: Bool)
        
        var topStackViewHeight: CGFloat {
            switch self {
            case let .expand(flag): return flag ? 72.0 : 100.0
            default: return 100
            }
        }
        
        var viewHeight: CGFloat {
            switch self {
            case let .expand(flag): return flag ? 445.0 : 100
            default: return 100
            }
        }
        
        var isExpand: Bool {
            return self == .expand(flag: true)
        }
    }

}

func ==(lhs: FamilyItemView.State, rhs: FamilyItemView.State) -> Bool {
    switch (lhs, rhs) {
    case (.firstLaunch, .firstLaunch): return true
    case let(.viewing(leftShowArrow), .viewing(rightShowArrow)):
        return leftShowArrow == rightShowArrow
    case let(.expand(leftFlag), .expand(rightFlag)):
        return leftFlag == rightFlag
    case (.editing, .editing):
        return true
        
    default:
        return false
    }
}


