//
//  ChildMenuView.swift
//  TuckrBox
//
//  Created by Steven Tao on 15/7/2016.
//  Copyright © 2016 ROKO. All rights reserved.
//

import UIKit

class ChildMenuView: UIView {
    
    typealias Model = ChildMenuViewModel
    typealias ModelDidChangeAction = (view: ChildMenuView, model: Model) -> Void
    
    // MARK: Properties
    @IBOutlet weak var tableView: UITableView!
    private var _model: Model!
    var model = ChildMenuViewModel.initial {
        didSet {
            tableView.reloadData()
        }
    }
    var state = State.firstLaunch {
        didSet {
            switch state {
            case .firstLaunch:
                let cellIdentifier = ClassName(ChildMenuTableViewCell)
                tableView.registerNib(UINib(nibName: cellIdentifier, bundle: nil), forCellReuseIdentifier: cellIdentifier)
            case .viewing:
                tableView.reloadData()
            }
        }
    }
    var modelDidChangeAction: ModelDidChangeAction?
    
    // MARK: View Life Cycle
    
    override func awakeFromNib() {
        loadFromNib()
        state = State.firstLaunch
    }

    // MARK: - Helper
    
    func setModelDidChangeAction(action: ModelDidChangeAction) {
        modelDidChangeAction = action
    }

}

// MARK: - UITableViewDataSource

extension ChildMenuView : UITableViewDataSource {
    
    func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return state == .firstLaunch ? 0 : model.children.count
    }
    
    func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCellWithIdentifier(ClassName(ChildMenuTableViewCell), forIndexPath: indexPath) as! ChildMenuTableViewCell
        let child = model.children[indexPath.row]
        //cell.iconView.backgroundColor = UIColor(hexString: child.iconColor.colorCode)
        cell.iconImageView.image = UIImage(named: child.iconColor.imageName)
        cell.nameLabel.text = child.name
        cell.nameLabel.textColor = model.selectedIndex == indexPath.row ? UIColor.whiteColor() : UIColor(hexString: 0x4C4C4C)
        cell.backgroundColor = model.selectedIndex == indexPath.row ? Styles.blueColor : UIColor.whiteColor()
        cell.circleArrowButton.selected = model.selectedIndex == indexPath.row
        
        return cell
    }
    
    func tableView(tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let headerView = UIView()
        headerView.backgroundColor = UIColor.clearColor()
        return headerView
    }
    
}

// MARK: - UITableViewDelegate

extension ChildMenuView : UITableViewDelegate {
    
    func tableView(tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 10
    }
    
    func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        return 83.0
    }
    
    func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        tableView.deselectRowAtIndexPath(indexPath, animated: false)
        Global.currentUser?.selectedChildIndex = indexPath.row
        modelDidChangeAction?(view: self, model: model)
    }
}

