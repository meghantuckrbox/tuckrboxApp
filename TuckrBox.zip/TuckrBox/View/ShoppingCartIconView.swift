//
//  ShoppingCartIconView.swift
//  TuckrBox
//
//  Created by Steven Tao on 15/7/2016.
//  Copyright © 2016 ROKO. All rights reserved.
//

import UIKit

class ShoppingCartIconView: UIView {

    typealias TappedAction = () -> Void
    
    // MARK: Properties
    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var numberLabel: UILabel!
    var tappedAction: TappedAction?
    
    // MARK: Helper
    
    func setNumber(number: Int, color: UIColor?) {
        numberLabel.text = String(number)
        if color != nil {
            numberLabel.backgroundColor = color
            numberLabel.layer.cornerRadius = number == 0 ? 7 : 2
        }
    }
    
    // MARK: Action
    
    @IBAction func viewDidTapped() {
        tappedAction?()
    }
    

}
