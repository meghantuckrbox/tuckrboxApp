//
//  CollectionViewCell.swift
//  TuckrBox
//
//  Created by Steven Tao on 26/7/2016.
//  Copyright © 2016 ROKO. All rights reserved.
//

import UIKit

class CollectionViewCell: UICollectionViewCell {
    
    @IBOutlet var buttons: [UIButton]?
    @IBOutlet var labels: [UILabel]?
    @IBOutlet var textFields: [UITextField]?
    @IBOutlet var views: [UIView]?
    @IBOutlet var imageViews: [UIImageView]?
    @IBOutlet var layoutConstraints: [NSLayoutConstraint]?
    
}
