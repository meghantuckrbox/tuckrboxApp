//
//  FamilyItemViewModel.swift
//  TuckrBox
//
//  Created by Steven Tao on 13/7/2016.
//  Copyright © 2016 ROKO. All rights reserved.
//

import Foundation

struct FamilyItemViewModel: Equatable {
    
    enum FamilyItemViewBGColor: Int {
        case c3fbb65
        case ca237a4
        case c0093c4
        case cf7c800
        
        var colorCode: Int {
            switch self {
            case c3fbb65: return 0x3fbb65
            case ca237a4: return 0xa237a4
            case c0093c4: return 0x0093c4
            case cf7c800: return 0xf7c800
            }
        }
        
//        case ce4e4e4 // gray
//        case ca237a4 // purple
//        case c0093c4 // blue
//        case cff2833 // red
//        case cffffff // white
//        case c3fbb65 // green
//        case cf7c800 // yellow
        
        static var random: FamilyItemViewBGColor{
            return FamilyItemViewBGColor(rawValue: Int(arc4random_uniform(3)))!
        }
    }
    
    var child: Child
    var index: Int = 0
    var backgroundColor: FamilyItemViewBGColor
    
    /// Set of default data to be used for the model.
    static var initial: FamilyItemViewModel {
        return FamilyItemViewModel(child: Child.initial, index: 0)
    }
    
//    static func generateBackgroundColor(child: Child) ->  FamilyItemViewBGColor{
//        let randomColor = FamilyItemViewBGColor.random
//        if randomColor.colorCode == child.iconColor.colorCode {
//            if let color = FamilyItemViewBGColor(rawValue: randomColor.rawValue + 1) {
//                return color
//            } else {
//                return FamilyItemViewBGColor(rawValue: randomColor.rawValue - 1)!
//            }
//        }
//        return randomColor
//    }
    
    static func generateBackgroundColor(index: Int) ->  FamilyItemViewBGColor{
        if index < 3 {
            return FamilyItemViewBGColor(rawValue: index)!
        }
        let remain = index % 4
        return FamilyItemViewBGColor(rawValue: remain)!
    }
    
    // MARK: Initialization
    
    init(child: Child, index: Int) {
        self.child = child
        self.index = index
//        backgroundColor = FamilyItemViewModel.generateBackgroundColor(child)
        backgroundColor = FamilyItemViewModel.generateBackgroundColor(index)
    }
    
    

}

func ==(lhs: FamilyItemViewModel, rhs: FamilyItemViewModel) -> Bool {
    return lhs.child == rhs.child
}
