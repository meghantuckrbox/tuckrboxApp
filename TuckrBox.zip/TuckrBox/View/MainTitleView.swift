//
//  MainTitleView.swift
//  TuckrBox
//
//  Created by Steven Tao on 15/7/2016.
//  Copyright © 2016 ROKO. All rights reserved.
//

import UIKit

class MainTitleView: UIView {

    typealias TitleViewTappedAction = (view: MainTitleView) -> Void
    
    // MARK: Properties
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var dropDownImageView: UIImageView!
    var titleViewTappedAction: TitleViewTappedAction?

    
    // MARK: View Life Cycle
    
    override func awakeFromNib() {
        super.awakeFromNib()
//        loadFromNib()
    }
    
    // MARK: Action
    
    @IBAction func titleViewTapped() {
        titleViewTappedAction?(view: self)
    }
    
    /*
    // Only override drawRect: if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func drawRect(rect: CGRect) {
        // Drawing code
    }
    */
    
    

}
