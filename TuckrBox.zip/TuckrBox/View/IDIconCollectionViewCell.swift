//
//  IDIconCollectionViewCell.swift
//  TuckrBox
//
//  Created by Steven Tao on 15/7/2016.
//  Copyright © 2016 ROKO. All rights reserved.
//

import UIKit

class IDIconCollectionViewCell: UICollectionViewCell {

    // MARK: Properties
    @IBOutlet weak var iconView: UIImageView!
    @IBOutlet weak var selectedView: UIImageView!
    

    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        
        iconView.layer.borderColor = UIColor.blackColor().CGColor
        iconView.layer.borderWidth = 1
    }

}
