//
//  RoundTextFieldView.swift
//  TuckrBox
//
//  Created by Steven Tao on 12/7/2016.
//  Copyright © 2016 ROKO. All rights reserved.
//

import UIKit

class RoundTextFieldView: UIView {

    typealias ShowDatePickerAction = (view: RoundTextFieldView) -> Void
    typealias ShowPickerAction = (view: RoundTextFieldView) -> Void
    
    // MARK: Properties
    
    @IBOutlet weak var imageView: UIImageView!
    @IBOutlet weak var textField: UITextField!
    @IBOutlet weak var datePickerButton: UIButton!
    @IBOutlet weak var pickerButton: UIButton!
    @IBOutlet weak var dropDownImageView: UIImageView!
    @IBOutlet weak var imageViewWidth: NSLayoutConstraint!
    @IBOutlet weak var dropDownImageLeading: NSLayoutConstraint!
    @IBOutlet weak var delegate: UITextFieldDelegate? {
        didSet {
            textField.delegate = delegate
        }
    }
    var showDatePicker: Bool = false {
        didSet{
            dropDownImageView.hidden = !showDatePicker
            textField.userInteractionEnabled = !showDatePicker
            datePickerButton.hidden = !showDatePicker
        }
    }
    var showDatePickerAction: ShowDatePickerAction?
    
    var showPicker: Bool = false {
        didSet{
            textField.userInteractionEnabled = !showPicker
            pickerButton.hidden = !showPicker
        }
    }
    var showPickerAction: ShowPickerAction?
    
    
    var text: String? {
        get {
            return textField.text
        }
        set {
            textField.text = newValue
        }
    }
    
    var placeHolder: String? {
        didSet {
            textField.placeholder = placeHolder
        }
    }
    
    var image: UIImage? {
        didSet {
            imageView.image = image
        }
    }
    
    var secureTextEntry: Bool = false {
        didSet {
            textField.secureTextEntry = secureTextEntry
        }
    }
    
    var keyboardType: UIKeyboardType = .Default{
        didSet {
            textField.keyboardType = keyboardType
        }
    }
    
    var returnKeyType: UIReturnKeyType = .Default{
        didSet {
            textField.returnKeyType = returnKeyType
        }
    }
    
    var textAlignment: NSTextAlignment = .Center {
        didSet{
            textField.textAlignment = textAlignment
        }
    }
    
    var hideImageView: Bool = false {
        didSet{
            imageViewWidth.constant = hideImageView ? 0 : 40
        }
    }
    
    override func becomeFirstResponder() -> Bool{
        super.becomeFirstResponder()
        textField.becomeFirstResponder()
        return false
    }
    
    override func resignFirstResponder() -> Bool{
        super.resignFirstResponder()
        textField.resignFirstResponder()
        return false
    }
    
    // MARK: View Life Cycle
    
    override func awakeFromNib() {
        loadFromNib()?.roundCorner(false)
        if Env.iPhone4 || Env.iPhone5 {
            dropDownImageLeading.constant = -25
        }
    }

    // MARK: - Action
    
    @IBAction func datePickerButtonClicked(sender: UIButton) {
        showDatePickerAction?(view: self)
    }
    
    @IBAction func pickerButtonClicked(sender: UIButton) {
        showPickerAction?(view: self)
    }
    
}
