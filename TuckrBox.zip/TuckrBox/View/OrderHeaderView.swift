//
//  OrderHeaderView.swift
//  TuckrBox
//
//  Created by Steven Tao on 20/7/2016.
//  Copyright © 2016 ROKO. All rights reserved.
//

import UIKit

class OrderHeaderView: UITableViewCell {
    
    typealias EditButtonClickedAction = (child: Child) -> Void
    
    // MARK: Properties
    
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var editButton: UIButton!
    @IBOutlet weak var profileImage: UIImageView!
    var child: Child! {
        didSet {
            nameLabel.text = child.name
            profileImage.image = UIImage(named: child.iconColor.imageName)
        }
    }
    var editButtonClickedAction: EditButtonClickedAction?
    
    // MARK: View Life Cycle
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    // MARK: - Action
    
    @IBAction func editButtonClicked(sender: UIButton) {
        editButtonClickedAction?(child: child)
    }

}
