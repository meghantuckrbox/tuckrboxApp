//
//  OrderTableViewCell.swift
//  TuckrBox
//
//  Created by Steven Tao on 20/7/2016.
//  Copyright © 2016 ROKO. All rights reserved.
//

import UIKit

struct OrderTableViewCellModel {
    var child: Child
    var order: Order
}

class OrderTableViewCell: UITableViewCell {
    
    typealias ModelDidChangeAction = (cell: OrderTableViewCell, model: Model) -> Void
    typealias Model = OrderTableViewCellModel
    typealias InfoAction = (model: Model) -> Void
    
    // MARK: Properties
    
    @IBOutlet weak var mealImageView: UIImageView!
    @IBOutlet weak var minusButton: UIButton!
    @IBOutlet weak var addButton: UIButton!
    @IBOutlet weak var countLabel: UILabel!
    @IBOutlet weak var newLabel: UILabel!
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var sidesLabel: UILabel!
    @IBOutlet weak var seperatorView: UIView!
    @IBOutlet weak var InfoButton: UIButton!
    
    var infoAction: InfoAction?
    var modelDidChangeAction: ModelDidChangeAction?
    var model: Model! {
        didSet{
            titleLabel.text = model.order.meal.name
            countLabel.text = String(Int(model.order.count))
            mealImageView.image = UIImage(named: model.order.meal.image) 
        }
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    override func prepareForReuse() {
        seperatorView.hidden = false
    }

    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    // MARK: - Helper
    
    private func updateCount(value: Double) {
        model.order.count = min(3, max(0, model.order.count + value))
        countLabel.text = String(Int(model.order.count))
        modelDidChangeAction?(cell: self, model: model)
    }
    
    // MARK: - Action
    
    @IBAction func minusButtonTapped(sender: UIButton) {
        updateCount(-1)
    }
    
    @IBAction func addButtonTapped(sender: UIButton) {
        updateCount(1)
    }
    
    @IBAction func infoButtonTapped(sender: UIButton) {
        infoAction?(model: model)
    }

}
