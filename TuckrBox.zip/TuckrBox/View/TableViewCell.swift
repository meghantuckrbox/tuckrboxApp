//
//  TableViewCell.swift
//  ForceRank
//
//  Created by Steven Tao on 5/10/15.
//  Copyright © 2015 roko. All rights reserved.
//

import UIKit

class TableViewCell: UITableViewCell {

    @IBOutlet var buttons: [UIButton]?
    @IBOutlet var labels: [UILabel]?
    @IBOutlet var textFields: [UITextField]?
    @IBOutlet var views: [UIView]?
    @IBOutlet var imageViews: [UIImageView]?
    @IBOutlet var layoutConstraints: [NSLayoutConstraint]?
    @IBOutlet weak var datePickerView: MonthYearPickerView!
    @IBOutlet weak var datePickerViewHeight : NSLayoutConstraint!
    @IBOutlet var stackViews: [UIStackView]?
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

    override func prepareForReuse() {
        datePickerViewHeight?.constant = 0
        datePickerView?.hidden = true
    }


}
