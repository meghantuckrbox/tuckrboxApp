//
//  HistoryOrderTableViewCell.swift
//  TuckrBox
//
//  Created by Steven Tao on 26/7/2016.
//  Copyright © 2016 ROKO. All rights reserved.
//

import UIKit

class HistoryOrderTableViewCell: UITableViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
