//
//  ChildMenuViewState.swift
//  TuckrBox
//
//  Created by Steven Tao on 18/7/2016.
//  Copyright © 2016 ROKO. All rights reserved.
//

import Foundation

extension ChildMenuView {
    enum State : Equatable{
        case firstLaunch
        case viewing
    }
    
}

func ==(lhs: ChildMenuView.State, rhs: ChildMenuView.State) -> Bool {
    switch (lhs, rhs) {
    case (.firstLaunch, .firstLaunch): return true
    case (.viewing, .viewing):
        return true
        
    default:
        return false
    }
}