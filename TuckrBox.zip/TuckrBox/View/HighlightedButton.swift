//
//  HighlightedButton.swift
//  TuckrBox
//
//  Created by Steven Tao on 27/7/2016.
//  Copyright © 2016 ROKO. All rights reserved.
//

import UIKit

class HighlightedButton: UIButton {

    var originBackgroundColor: UIColor!
    
    override var highlighted: Bool {
        didSet {
            if highlighted {
                originBackgroundColor = backgroundColor
                backgroundColor = UIColor.lightGrayColor()
            } else {
                backgroundColor = originBackgroundColor
            }
        }
    }
    
    /*
    // Only override drawRect: if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func drawRect(rect: CGRect) {
        // Drawing code
    }
    */

}
