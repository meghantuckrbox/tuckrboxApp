//
//  ChildMenuViewModel.swift
//  TuckrBox
//
//  Created by Steven Tao on 15/7/2016.
//  Copyright © 2016 ROKO. All rights reserved.
//

import Foundation

struct ChildMenuViewModel: Equatable{
    
    // MARK: Properties
    var children: [Child]
    var selectedIndex: Int {
        return Global.currentUser?.selectedChildIndex ?? 0
    }
    
    var selectedChild: Child {
        return children[selectedIndex]
    }
    
    /// Set of default data to be used for the model.
    static var initial: ChildMenuViewModel {
        return ChildMenuViewModel(children: Global.currentUser?.children ?? [Child]())
    }
}

func ==(lhs: ChildMenuViewModel, rhs: ChildMenuViewModel) -> Bool {
    return lhs.children == rhs.children && lhs.selectedIndex == rhs.selectedIndex
}