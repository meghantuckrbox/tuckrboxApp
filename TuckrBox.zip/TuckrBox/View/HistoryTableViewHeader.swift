//
//  HistoryTableViewHeader.swift
//  TuckrBox
//
//  Created by Steven Tao on 26/7/2016.
//  Copyright © 2016 ROKO. All rights reserved.
//

import UIKit

struct HistoryTableViewHeaderModel {
    var key: String
    var isExpand: Bool
}

class HistoryTableViewHeader: UITableViewCell {
    
    typealias TapAction = (model: HistoryTableViewHeaderModel) -> Void
    
    // MARK: Properties
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var arrowImageView: UIImageView!
    var tapAction: TapAction?
    var model: HistoryTableViewHeaderModel! {
        didSet {
            nameLabel.text = model.key
            arrowImageView.image = UIImage(named: !model.isExpand ? "LeftArrowIcon" : "DownArrowIcon")
        }
    }
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    // MARK: - Action
    
    @IBAction func viewDidTapped(sender: UIButton) {
        tapAction?(model: model)
    }
}
