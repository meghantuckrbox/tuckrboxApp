//
//  FamilyItemTableViewCell.swift
//  TuckrBox
//
//  Created by Steven Tao on 14/7/2016.
//  Copyright © 2016 ROKO. All rights reserved.
//

import UIKit

class FamilyItemTableViewCell: UITableViewCell {

    // MARK: Properties
    @IBOutlet weak var familyItemView: FamilyItemView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
