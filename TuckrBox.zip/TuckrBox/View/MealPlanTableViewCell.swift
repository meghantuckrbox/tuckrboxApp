//
//  MealPlanTableViewCell.swift
//  TuckrBox
//
//  Created by Steven Tao on 21/7/2016.
//  Copyright © 2016 ROKO. All rights reserved.
//

import UIKit

struct MealPlanTableViewCellModel {
    var plan: Plan
}

class MealPlanTableViewCell: UITableViewCell {

    typealias Model = MealPlanTableViewCellModel
    
    // MARK: Properties
    @IBOutlet weak var planImageView: UIImageView!
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var detailLabel: UILabel!
    @IBOutlet weak var priceLabel: UILabel!
    @IBOutlet weak var listLabel: UILabel!
    
    var model: Model! {
        didSet {
            
        }
    }
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        if Env.iPhone4 || Env.iPhone5 {
            detailLabel.setFontSize(10)
        }
    }

    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
}
