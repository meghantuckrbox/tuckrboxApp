//
//  MealTableViewCell.swift
//  TuckrBox
//
//  Created by Steven Tao on 16/7/2016.
//  Copyright © 2016 ROKO. All rights reserved.
//

import UIKit

struct MealTableViewCellModel {
    var meal: Meal
}

class MealTableViewCell: UITableViewCell {
    
    typealias AddAction = (model: Model) -> Void
    typealias InfoAction = (model: Model) -> Void
    typealias Model = MealTableViewCellModel
    
    // MARK: Properties
    
    @IBOutlet weak var mealImageView: UIImageView!
    @IBOutlet weak var selectedView: UIView!
    @IBOutlet weak var completedView: UIView!
    @IBOutlet weak var selectedViewLabel: UILabel!
    @IBOutlet weak var infoButton: UIButton!
    @IBOutlet weak var addButton: UIButton!
    @IBOutlet weak var newLabel: UILabel!
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var sidesLabel: UILabel!
    @IBOutlet weak var descriptionLabel: UILabel!
    var model: Model! {
        didSet {
            titleLabel.text = model.meal.name
            mealImageView.image = UIImage(named: model.meal.image)
        }
    }
    var addAction: AddAction?
    var infoAction: InfoAction?
    
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        
        selectedView.layer.borderColor = Styles.greenColor.CGColor
        selectedView.layer.borderWidth = 5
        
        completedView.layer.borderColor = Styles.greenColor.CGColor
        completedView.layer.borderWidth = 5
    }

    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }
    
    // MARK: - Action
    
    @IBAction func addButtonClicked(sender: UIButton) {
        addAction?(model: model)
    }
    
    @IBAction func infoButtonClicked(sender: UIButton) {
        infoAction?(model: model)
    }

}
